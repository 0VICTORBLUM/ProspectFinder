#!/usr/bin/env node
// Gera data/cnpj/empresas.jsonl a partir dos arquivos oficiais dos Dados Abertos do CNPJ (Receita Federal).
// Uso:
//   node scripts/import-cnpj.mjs --estabelecimentos "dir/Estabelecimentos*.csv" --empresas "dir/Empresas*.csv" \
//        --municipios dir/Municipios.csv --uf PR,SC,SP --cnaes 4330401,4330403 [--out data/cnpj/empresas.jsonl]
// Os arquivos devem estar descompactados (ISO-8859-1, separador ";"). Processa em streaming, sem carregar tudo em memória.
import fs from "node:fs";
import path from "node:path";
import readline from "node:readline";
import { cleanCnaes, EMP, estabToPartial, finalizeRecord, parseLine } from "./import-cnpj-core.mjs";

const DEFAULT_CNAES = "4330401,4330403,4330402,4330499,4120400,4399101,4399199,4679699,4744099";

function arg(name, def) {
  const i = process.argv.indexOf(`--${name}`);
  return i > -1 ? process.argv[i + 1] : def;
}

function expand(spec) {
  if (!spec) return [];
  return spec.split(",").flatMap((p) => {
    if (!p.includes("*")) return [p];
    const dir = path.dirname(p);
    const re = new RegExp(`^${path.basename(p).replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*")}$`, "i");
    return fs.readdirSync(dir).filter((f) => re.test(f)).map((f) => path.join(dir, f));
  });
}

async function* lines(file) {
  const rl = readline.createInterface({ input: fs.createReadStream(file, { encoding: "latin1" }), crlfDelay: Infinity });
  for await (const l of rl) if (l) yield l;
}

const est = expand(arg("estabelecimentos"));
const emp = expand(arg("empresas"));
const munFile = arg("municipios");
const ufs = new Set((arg("uf", "PR,SC,SP")).split(",").map((s) => s.trim().toUpperCase()));
const cnaes = new Set(cleanCnaes((arg("cnaes", DEFAULT_CNAES)).split(",").map((c) => c.replace(/\D/g, "")).join(",")));
const out = arg("out", "data/cnpj/empresas.jsonl");

if (!est.length || !emp.length || !munFile) {
  console.error("Informe --estabelecimentos, --empresas e --municipios. Veja o cabeçalho deste arquivo.");
  process.exit(1);
}

const municipios = new Map();
for await (const l of lines(munFile)) {
  const f = parseLine(l);
  municipios.set(f[0], (f[1] ?? "").trim());
}
console.log(`Municípios carregados: ${municipios.size}`);

const partials = new Map(); // cnpj básico -> registros parciais
let scanned = 0;
for (const file of est) {
  console.log(`Lendo ${file}`);
  for await (const l of lines(file)) {
    scanned++;
    const p = estabToPartial(parseLine(l), { ufs, cnaes, municipios });
    if (p) { const arr = partials.get(p.basico) ?? []; arr.push(p); partials.set(p.basico, arr); }
  }
}
console.log(`Estabelecimentos lidos: ${scanned}; selecionados: ${[...partials.values()].reduce((a, b) => a + b.length, 0)}`);

fs.mkdirSync(path.dirname(out), { recursive: true });
const ws = fs.createWriteStream(out, { encoding: "utf8" });
let written = 0;
const seen = new Set();
for (const file of emp) {
  console.log(`Lendo ${file}`);
  for await (const l of lines(file)) {
    const f = parseLine(l);
    const basico = (f[EMP.basico] ?? "").padStart(8, "0");
    const list = partials.get(basico);
    if (!list) continue;
    for (const p of list) {
      ws.write(JSON.stringify(finalizeRecord(p, f)) + "\n");
      seen.add(p.cnpj);
      written++;
    }
    partials.delete(basico);
  }
}
ws.end();
console.log(`Concluído: ${written} registros em ${out}. Sem razão social (não encontrados em Empresas): ${[...partials.values()].reduce((a, b) => a + b.length, 0)}`);
