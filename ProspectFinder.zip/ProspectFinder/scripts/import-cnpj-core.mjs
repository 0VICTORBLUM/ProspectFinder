// Funções puras do importador de Dados Abertos do CNPJ (layout oficial da Receita Federal).
// O layout abaixo foi escrito a partir da documentação pública e testado apenas com linhas sintéticas:
// confirme-o contra os arquivos mais recentes antes de depender dele (veja o README).

/** Divide uma linha CSV com campos entre aspas e separador ";". */
export function parseLine(line) {
  const out = [];
  let cur = "";
  let inQ = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (inQ) {
      if (c === '"') {
        if (line[i + 1] === '"') { cur += '"'; i++; } else inQ = false;
      } else cur += c;
    } else if (c === '"') inQ = true;
    else if (c === ";") { out.push(cur); cur = ""; }
    else cur += c;
  }
  out.push(cur);
  return out;
}

// Posições no arquivo ESTABELECIMENTOS
export const E = {
  basico: 0, ordem: 1, dv: 2, matriz: 3, fantasia: 4, situacao: 5, cnaePrincipal: 11, cnaesSec: 12,
  uf: 19, municipio: 20, ddd1: 21, tel1: 22, email: 27,
};
// Posições no arquivo EMPRESAS
export const EMP = { basico: 0, razao: 1, natureza: 2 };

const NATUREZA_EMPRESARIO_INDIVIDUAL = "2135";

export function cleanCnaes(s) {
  return (s ?? "").split(",").map((x) => x.replace(/\D/g, "")).filter((x) => x.length === 7);
}

/** Retorna o registro parcial ou null se não passar no filtro (UF + CNAE). */
export function estabToPartial(f, { ufs, cnaes, municipios }) {
  const uf = (f[E.uf] ?? "").trim().toUpperCase();
  if (!ufs.has(uf)) return null;
  const principal = (f[E.cnaePrincipal] ?? "").replace(/\D/g, "");
  const secundarios = cleanCnaes(f[E.cnaesSec]);
  if (!cnaes.has(principal) && !secundarios.some((c) => cnaes.has(c))) return null;
  const basico = (f[E.basico] ?? "").padStart(8, "0");
  return {
    basico,
    cnpj: `${basico}${(f[E.ordem] ?? "").padStart(4, "0")}${(f[E.dv] ?? "").padStart(2, "0")}`,
    nomeFantasia: (f[E.fantasia] ?? "").trim() || null,
    situacao: (f[E.situacao] ?? "").padStart(2, "0"),
    matriz: f[E.matriz] === "1",
    cnaePrincipal: principal,
    cnaesSecundarios: secundarios,
    uf,
    city: municipios.get(f[E.municipio] ?? "") ?? "",
    ddd: (f[E.ddd1] ?? "").trim() || null,
    phone: (f[E.tel1] ?? "").trim() || null,
    email: (f[E.email] ?? "").trim().toLowerCase() || null,
  };
}

/** Minimização (LGPD): e-mail de empresário individual tende a ser pessoal; não é mantido. */
export function finalizeRecord(partial, empresaFields) {
  const { basico, ...rest } = partial;
  const natureza = (empresaFields?.[EMP.natureza] ?? "").trim();
  return {
    ...rest,
    razaoSocial: (empresaFields?.[EMP.razao] ?? "").trim(),
    email: natureza === NATUREZA_EMPRESARIO_INDIVIDUAL ? null : rest.email,
  };
}
