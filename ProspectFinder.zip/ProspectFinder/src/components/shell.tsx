"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, Search, Table2, X } from "lucide-react";
import { useState } from "react";

const NAV = [
  { href: "/pesquisa", label: "Pesquisa", icon: Search },
  { href: "/leads", label: "Leads", icon: Table2 },
];

export function Shell({ children }: { children: React.ReactNode }) {
  const path = usePathname();
  const [open, setOpen] = useState(false);
  if (path === "/login") return <main>{children}</main>;

  const links = (
    <nav className="flex flex-col gap-1" aria-label="Principal">
      {NAV.map(({ href, label, icon: Icon }) => {
        const active = path.startsWith(href);
        return (
          <Link key={href} href={href} onClick={() => setOpen(false)} aria-current={active ? "page" : undefined}
            className={`flex h-9 items-center gap-2 rounded-md border-l-2 px-3 text-sm ${active ? "border-accent bg-paper font-medium text-accent" : "border-transparent text-muted hover:bg-paper hover:text-ink"}`}>
            <Icon size={16} aria-hidden /> {label}
          </Link>
        );
      })}
    </nav>
  );

  return (
    <div className="min-h-screen md:grid md:grid-cols-[220px_1fr]">
      <aside className="hidden border-r border-line bg-surface p-4 md:block">
        <p className="mb-6 px-3 text-base font-semibold tracking-tight">Prospect Finder</p>
        {links}
      </aside>
      <header className="flex items-center justify-between border-b border-line bg-surface px-4 py-2 md:hidden">
        <p className="font-semibold">Prospect Finder</p>
        <button aria-label={open ? "Fechar menu" : "Abrir menu"} aria-expanded={open} onClick={() => setOpen(!open)} className="grid h-9 w-9 place-items-center rounded-md hover:bg-paper">
          {open ? <X size={18} /> : <Menu size={18} />}
        </button>
      </header>
      {open && <div className="border-b border-line bg-surface p-3 md:hidden">{links}</div>}
      <main className="min-w-0 p-4 md:p-8">{children}</main>
    </div>
  );
}
