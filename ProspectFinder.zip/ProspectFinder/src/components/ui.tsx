"use client";
import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode, SelectHTMLAttributes } from "react";

const cx = (...c: (string | false | undefined)[]) => c.filter(Boolean).join(" ");

export function Button({ variant = "primary", className, ...p }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "secondary" | "ghost" | "danger" }) {
  const styles = {
    primary: "bg-accent text-accent-ink hover:brightness-110 disabled:opacity-50",
    secondary: "border border-line bg-surface hover:bg-paper disabled:opacity-50",
    ghost: "hover:bg-paper disabled:opacity-50",
    danger: "bg-bad-ink text-white hover:brightness-110 disabled:opacity-50",
  }[variant];
  return <button {...p} className={cx("inline-flex h-9 items-center justify-center gap-2 rounded-md px-3 text-sm font-medium transition-colors disabled:cursor-not-allowed", styles, className)} />;
}

const field = "h-9 w-full rounded-md border border-line bg-surface px-2.5 text-sm placeholder:text-muted/70";
export const Input = (p: InputHTMLAttributes<HTMLInputElement>) => <input {...p} className={cx(field, p.className)} />;
export const Select = (p: SelectHTMLAttributes<HTMLSelectElement>) => <select {...p} className={cx(field, p.className)} />;

export function Field({ label, hint, children, htmlFor }: { label: string; hint?: string; children: ReactNode; htmlFor?: string }) {
  return (
    <div className="space-y-1">
      <label htmlFor={htmlFor} className="block text-sm font-medium">{label}</label>
      {children}
      {hint && <p className="text-xs text-muted">{hint}</p>}
    </div>
  );
}

export function Notice({ tone, title, children }: { tone: "warn" | "bad" | "ok" | "info"; title?: string; children?: ReactNode }) {
  const t = {
    warn: "bg-warn-bg text-warn-ink border-warn-ink/20",
    bad: "bg-bad-bg text-bad-ink border-bad-ink/20",
    ok: "bg-ok-bg text-ok-ink border-ok-ink/20",
    info: "bg-surface text-ink border-line",
  }[tone];
  return (
    <div role={tone === "bad" ? "alert" : "status"} className={cx("rounded-md border px-3 py-2 text-sm", t)}>
      {title && <p className="font-medium">{title}</p>}
      {children && <div className={title ? "mt-0.5" : ""}>{children}</div>}
    </div>
  );
}

export function Badge({ children, tone = "neutral" }: { children: ReactNode; tone?: "neutral" | "warn" | "ok" | "bad" }) {
  const t = { neutral: "bg-paper text-muted border-line", warn: "bg-warn-bg text-warn-ink border-warn-ink/20", ok: "bg-ok-bg text-ok-ink border-ok-ink/20", bad: "bg-bad-bg text-bad-ink border-bad-ink/20" }[tone];
  return <span className={cx("inline-flex items-center rounded border px-1.5 py-0.5 text-xs", t)}>{children}</span>;
}

export function Spinner() {
  return <span aria-hidden className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />;
}

export async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, { ...init, headers: { "content-type": "application/json", ...(init?.headers ?? {}) } });
  if (res.status === 401) { window.location.href = "/login"; throw new Error("Sessão expirada."); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const d = Array.isArray(data.details) ? ` ${data.details.join(" ")}` : "";
    throw new Error(`${data.error ?? `Erro ${res.status}`}${d}`);
  }
  return data as T;
}
