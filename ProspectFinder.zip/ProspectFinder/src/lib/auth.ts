/** Autenticação por token compartilhado (uso interno). Usa Web Crypto: funciona no middleware (Edge) e no Node. */
export const COOKIE_NAME = "pf_session";

export async function sha256Hex(input: string): Promise<string> {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(input));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

export function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

export type AuthDecision =
  | { ok: true }
  | { ok: false; status: 401 | 503; message: string };

interface AuthInput {
  token: string | undefined; // APP_ACCESS_TOKEN
  nodeEnv: string | undefined;
  authorization: string | null;
  cookie: string | undefined;
}

/**
 * - Sem APP_ACCESS_TOKEN: libera só fora de produção; em produção bloqueia tudo (falha fechada).
 * - Com token: aceita "Authorization: Bearer <token>" ou cookie com o hash do token.
 */
export async function decide(input: AuthInput): Promise<AuthDecision> {
  if (!input.token) {
    if (input.nodeEnv === "production") {
      return { ok: false, status: 503, message: "APP_ACCESS_TOKEN não configurado: acesso bloqueado em produção." };
    }
    return { ok: true };
  }
  const bearer = input.authorization?.match(/^Bearer\s+(.+)$/i)?.[1];
  if (bearer && safeEqual(await sha256Hex(bearer), await sha256Hex(input.token))) return { ok: true };
  if (input.cookie && safeEqual(input.cookie, await sha256Hex(input.token))) return { ok: true };
  return { ok: false, status: 401, message: "Não autorizado." };
}

export function requestAuthInput(req: Request): AuthInput {
  const cookieHeader = req.headers.get("cookie") ?? "";
  const cookie = cookieHeader
    .split(";")
    .map((c) => c.trim())
    .find((c) => c.startsWith(`${COOKIE_NAME}=`))
    ?.slice(COOKIE_NAME.length + 1);
  return {
    token: process.env.APP_ACCESS_TOKEN,
    nodeEnv: process.env.NODE_ENV,
    authorization: req.headers.get("authorization"),
    cookie,
  };
}

export async function authorize(req: Request): Promise<AuthDecision> {
  return decide(requestAuthInput(req));
}
