export interface Page<T> {
  items: T[];
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
}

export function paginate<T>(items: T[], page: number, pageSize: number): Page<T> {
  const size = Math.min(Math.max(Math.floor(pageSize) || 25, 1), 200);
  const totalPages = Math.max(1, Math.ceil(items.length / size));
  const current = Math.min(Math.max(Math.floor(page) || 1, 1), totalPages);
  const start = (current - 1) * size;
  return { items: items.slice(start, start + size), page: current, pageSize: size, total: items.length, totalPages };
}
