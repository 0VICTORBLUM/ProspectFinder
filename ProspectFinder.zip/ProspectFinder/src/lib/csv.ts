const FORMULA_START = /^[=+\-@\t\r]/;

/** Neutraliza valores que planilhas interpretariam como fórmulas (CSV injection). */
export function sanitizeCsvCell(value: unknown): string {
  let s = value === null || value === undefined ? "" : String(value);
  if (FORMULA_START.test(s) || /^\s+[=+\-@]/.test(s)) s = `'${s}`;
  if (/[";\n\r,]/.test(s)) s = `"${s.replace(/"/g, '""')}"`;
  return s;
}

/** Separador ";" e BOM para abrir corretamente no Excel em português. */
export function toCsv(headers: string[], rows: unknown[][]): string {
  const lines = [headers, ...rows].map((r) => r.map(sanitizeCsvCell).join(";"));
  return `\uFEFF${lines.join("\r\n")}\r\n`;
}
