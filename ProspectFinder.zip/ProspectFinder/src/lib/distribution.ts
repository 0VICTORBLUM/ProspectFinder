/**
 * Distribui um limite total entre segmentos conforme percentuais (maior resto).
 * Percentuais não precisam somar 100: são normalizados.
 */
export function allocate(total: number, weights: Record<string, number>): Record<string, number> {
  const entries = Object.entries(weights).filter(([, w]) => w > 0);
  const sum = entries.reduce((a, [, w]) => a + w, 0);
  const result: Record<string, number> = Object.fromEntries(Object.keys(weights).map((k) => [k, 0]));
  if (total <= 0 || sum <= 0) return result;
  const raw = entries.map(([k, w]) => ({ k, exact: (total * w) / sum }));
  let assigned = 0;
  for (const r of raw) {
    result[r.k] = Math.floor(r.exact);
    assigned += result[r.k] ?? 0;
  }
  const order = [...raw].sort((a, b) => (b.exact % 1) - (a.exact % 1));
  for (let i = 0; assigned < total; i = (i + 1) % order.length) {
    const item = order[i];
    if (!item) break;
    result[item.k] = (result[item.k] ?? 0) + 1;
    assigned++;
  }
  return result;
}

export interface DistributionReport {
  segment: string;
  target: number;
  achieved: number;
  targetPct: number;
  achievedPct: number;
  met: boolean;
}

/** Compara metas e resultados sem afirmar cumprimento quando não houve. */
export function distributionReport(
  targets: Record<string, number>,
  achieved: Record<string, number>,
): DistributionReport[] {
  const totalTarget = Object.values(targets).reduce((a, b) => a + b, 0);
  const totalAchieved = Object.values(achieved).reduce((a, b) => a + b, 0);
  return Object.keys(targets).map((segment) => {
    const target = targets[segment] ?? 0;
    const got = achieved[segment] ?? 0;
    return {
      segment,
      target,
      achieved: got,
      targetPct: totalTarget ? Math.round((target / totalTarget) * 100) : 0,
      achievedPct: totalAchieved ? Math.round((got / totalAchieved) * 100) : 0,
      met: got >= target,
    };
  });
}
