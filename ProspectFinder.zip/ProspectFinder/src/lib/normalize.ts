import { UFS, type Uf } from "./types";

const stripAccents = (s: string) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "");

export function onlyDigits(input: string | null | undefined): string {
  return (input ?? "").replace(/\D/g, "");
}

/** Devolve 14 dígitos ou null. Não valida dígitos verificadores (veja isValidCnpj). */
export function normalizeCnpj(input: string | null | undefined): string | null {
  const d = onlyDigits(input);
  return d.length === 14 ? d : null;
}

export function isValidCnpj(input: string | null | undefined): boolean {
  const d = normalizeCnpj(input);
  if (!d || /^(\d)\1{13}$/.test(d)) return false;
  const calc = (base: string, weights: number[]) => {
    const sum = base.split("").reduce((acc, ch, i) => acc + Number(ch) * (weights[i] ?? 0), 0);
    const r = sum % 11;
    return r < 2 ? 0 : 11 - r;
  };
  const w1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
  const w2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
  const d1 = calc(d.slice(0, 12), w1);
  const d2 = calc(d.slice(0, 12) + d1, w2);
  return d.endsWith(`${d1}${d2}`);
}

export function formatCnpj(input: string | null | undefined): string {
  const d = normalizeCnpj(input);
  if (!d) return input ?? "";
  return `${d.slice(0, 2)}.${d.slice(2, 5)}.${d.slice(5, 8)}/${d.slice(8, 12)}-${d.slice(12)}`;
}

export interface NormalizedPhone {
  digits: string; // DDD + número
  formatted: string; // (41) 99999-9999
  type: "movel" | "fixo";
}

/** Normaliza telefones brasileiros. Aceita DDD separado. Retorna null se inválido. */
export function normalizePhone(input: string | null | undefined, ddd?: string | null): NormalizedPhone | null {
  let d = onlyDigits(input);
  const dddDigits = onlyDigits(ddd);
  if (dddDigits && d.length <= 9) d = dddDigits + d;
  if (d.startsWith("55") && (d.length === 12 || d.length === 13)) d = d.slice(2);
  if (d.startsWith("0") && d.length >= 11) d = d.replace(/^0+/, "");
  if (d.length !== 10 && d.length !== 11) return null;
  const area = Number(d.slice(0, 2));
  if (area < 11 || area > 99 || d.slice(0, 2).includes("0")) return null;
  const number = d.slice(2);
  if (d.length === 11) {
    if (number[0] !== "9") return null;
    return { digits: d, formatted: `(${d.slice(0, 2)}) ${number.slice(0, 5)}-${number.slice(5)}`, type: "movel" };
  }
  if (!/^[2-5]/.test(number)) return null; // fixo começa com 2 a 5
  return { digits: d, formatted: `(${d.slice(0, 2)}) ${number.slice(0, 4)}-${number.slice(4)}`, type: "fixo" };
}

const LEGAL_SUFFIXES = /\b(LTDA|EIRELI|EPP|MEI|ME|SLU|S\/?A|SA|CIA|COMPANHIA)\b/g;

export function normalizeCompanyName(name: string | null | undefined): string {
  return stripAccents(name ?? "")
    .toUpperCase()
    .replace(/&/g, " E ")
    .replace(/[^A-Z0-9/ ]+/g, " ")
    .replace(LEGAL_SUFFIXES, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function normalizeUf(input: string | null | undefined): Uf | null {
  const v = (input ?? "").trim().toUpperCase();
  return (UFS as readonly string[]).includes(v) ? (v as Uf) : null;
}

export function normalizeCity(input: string | null | undefined): string {
  return stripAccents(input ?? "")
    .toUpperCase()
    .replace(/[^A-Z0-9 ]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function normalizeCnae(input: string | null | undefined): string | null {
  const d = onlyDigits(input);
  return d.length === 7 ? d : null;
}

export function formatCnae(input: string | null | undefined): string {
  const d = normalizeCnae(input);
  return d ? `${d.slice(0, 4)}-${d.slice(4, 5)}/${d.slice(5)}` : (input ?? "");
}

export function normalizeWebsite(input: string | null | undefined): string | null {
  const raw = (input ?? "").trim();
  if (!raw) return null;
  try {
    const url = new URL(/^https?:\/\//i.test(raw) ? raw : `https://${raw}`);
    if (!url.hostname.includes(".")) return null;
    return `${url.protocol}//${url.hostname.toLowerCase().replace(/^www\./, "")}`;
  } catch {
    return null;
  }
}

export function websiteHost(input: string | null | undefined): string | null {
  const w = normalizeWebsite(input);
  return w ? new URL(w).hostname : null;
}

export function stripAccentsLower(s: string): string {
  return stripAccents(s).toLowerCase();
}
