import { JWT } from "google-auth-library";
import type { Lead, SearchResult } from "../types";
import { SEGMENT_LABELS } from "../segments";
import { STATUS_LABELS } from "../types";
import { formatCnae, formatCnpj } from "../normalize";
import { StoreError, type LeadStore, type UpsertSummary } from "./types";

export interface SheetsRequest {
  method: "GET" | "POST";
  path: string; // relativo a /v4/spreadsheets/{id}
  query?: Record<string, string>;
  body?: unknown;
}
export type SheetsTransport = (req: SheetsRequest) => Promise<{ status: number; data: unknown }>;

export const LEADS_TAB = "Leads";
export const SEARCHES_TAB = "Pesquisas";
export const LEADS_HEADERS = [
  "id", "empresa", "cnpj", "segmento", "cidade", "uf", "telefone", "email", "website", "cnae", "pontuacao",
  "origem", "descoberto_em", "status", "observacoes", "demonstracao", "atualizado_em", "dados_json",
];
const SEARCH_HEADERS = ["id", "atualizado_em", "dados_json"];
const LAST_COL: Record<string, string> = { [LEADS_TAB]: "R", [SEARCHES_TAB]: "C" };
const CHUNK = 100;

export interface SheetsOptions {
  spreadsheetId: string;
  transport: SheetsTransport;
  sleep?: (ms: number) => Promise<void>;
  maxAttempts?: number;
}

export function leadToRow(l: Lead): string[] {
  return [
    l.id, l.razaoSocial, l.cnpj ? formatCnpj(l.cnpj) : "", SEGMENT_LABELS[l.segment], l.city ?? "", l.uf ?? "",
    l.phone ?? "", l.email ?? "", l.website ?? "", l.cnaePrincipal ? formatCnae(l.cnaePrincipal) : "", String(l.score),
    l.sources.join(", "), l.discoveredAt, STATUS_LABELS[l.status], l.notes, l.isDemo ? "SIM (fictício)" : "não",
    l.updatedAt, JSON.stringify(l),
  ];
}

export class SheetsStore implements LeadStore {
  kind = "sheets" as const;
  persistent = true;
  private ready: Promise<void> | null = null;
  private sleep: (ms: number) => Promise<void>;
  private maxAttempts: number;

  constructor(private opts: SheetsOptions) {
    this.sleep = opts.sleep ?? ((ms) => new Promise((r) => setTimeout(r, ms)));
    this.maxAttempts = opts.maxAttempts ?? 5;
  }

  /** Chamada com retentativa e backoff exponencial para 429/5xx/falhas de rede. */
  private async call(req: SheetsRequest): Promise<unknown> {
    let lastErr: unknown;
    for (let attempt = 1; attempt <= this.maxAttempts; attempt++) {
      try {
        const res = await this.opts.transport(req);
        if (res.status >= 200 && res.status < 300) return res.data;
        const retryable = res.status === 429 || res.status >= 500;
        const err = new StoreError(`Google Sheets respondeu ${res.status}${describe(res.data)}`, retryable, res.status);
        if (!retryable) throw err;
        lastErr = err;
      } catch (e) {
        if (e instanceof StoreError && !e.retryable) throw e;
        lastErr = e instanceof StoreError ? e : new StoreError(`Falha de rede ao acessar o Google Sheets: ${(e as Error).message}`, true);
      }
      if (attempt < this.maxAttempts) await this.sleep(Math.min(8000, 500 * 2 ** (attempt - 1)));
    }
    throw lastErr instanceof StoreError ? lastErr : new StoreError("Falha ao acessar o Google Sheets.", true);
  }

  private ensureTabs(): Promise<void> {
    this.ready ??= (async () => {
      const meta = (await this.call({ method: "GET", path: "", query: { fields: "sheets.properties.title" } })) as {
        sheets?: { properties?: { title?: string } }[];
      };
      const have = new Set((meta.sheets ?? []).map((s) => s.properties?.title));
      const missing = [LEADS_TAB, SEARCHES_TAB].filter((t) => !have.has(t));
      if (missing.length) {
        await this.call({ method: "POST", path: ":batchUpdate", body: { requests: missing.map((title) => ({ addSheet: { properties: { title } } })) } });
      }
      for (const [tab, headers] of [[LEADS_TAB, LEADS_HEADERS], [SEARCHES_TAB, SEARCH_HEADERS]] as const) {
        const first = (await this.call({ method: "GET", path: `/values/${encodeURIComponent(`${tab}!A1:${LAST_COL[tab]}1`)}` })) as { values?: string[][] };
        if (!first.values?.[0]?.length) {
          await this.call({
            method: "POST", path: `/values:batchUpdate`,
            body: { valueInputOption: "RAW", data: [{ range: `${tab}!A1:${LAST_COL[tab]}1`, values: [headers] }] },
          });
        }
      }
    })().catch((e) => { this.ready = null; throw e; });
    return this.ready;
  }

  private async readIdIndex(tab: string): Promise<Map<string, number>> {
    const data = (await this.call({ method: "GET", path: `/values/${encodeURIComponent(`${tab}!A2:A`)}` })) as { values?: string[][] };
    const map = new Map<string, number>();
    (data.values ?? []).forEach((row, i) => { if (row[0]) map.set(row[0], i + 2); });
    return map;
  }

  private async upsertRows(tab: string, rows: { id: string; values: string[] }[]): Promise<UpsertSummary> {
    await this.ensureTabs();
    // Último valor vence dentro do mesmo lote (evita duplicar a mesma linha).
    const unique = [...new Map(rows.map((r) => [r.id, r])).values()];
    const index = await this.readIdIndex(tab);
    const updates = unique.filter((r) => index.has(r.id));
    const inserts = unique.filter((r) => !index.has(r.id));
    const last = LAST_COL[tab];
    for (let i = 0; i < updates.length; i += CHUNK) {
      await this.call({
        method: "POST", path: "/values:batchUpdate",
        body: {
          valueInputOption: "RAW",
          data: updates.slice(i, i + CHUNK).map((r) => ({ range: `${tab}!A${index.get(r.id)}:${last}${index.get(r.id)}`, values: [r.values] })),
        },
      });
    }
    for (let i = 0; i < inserts.length; i += CHUNK) {
      await this.call({
        method: "POST", path: `/values/${encodeURIComponent(`${tab}!A:A`)}:append`,
        query: { valueInputOption: "RAW", insertDataOption: "INSERT_ROWS" },
        body: { values: inserts.slice(i, i + CHUNK).map((r) => r.values) },
      });
    }
    return { inserted: inserts.length, updated: updates.length };
  }

  private async readAll(tab: string): Promise<string[][]> {
    await this.ensureTabs();
    const data = (await this.call({ method: "GET", path: `/values/${encodeURIComponent(`${tab}!A2:${LAST_COL[tab]}`)}` })) as { values?: string[][] };
    return data.values ?? [];
  }

  async listLeads(): Promise<Lead[]> {
    const rows = await this.readAll(LEADS_TAB);
    const leads: Lead[] = [];
    for (const row of rows) {
      const json = row[17];
      if (!json) continue;
      try { leads.push(JSON.parse(json) as Lead); } catch { /* linha editada/corrompida: ignorada */ }
    }
    return leads;
  }

  async getLead(id: string) { return (await this.listLeads()).find((l) => l.id === id) ?? null; }

  upsertLeads(leads: Lead[]) {
    return this.upsertRows(LEADS_TAB, leads.map((l) => ({ id: l.id, values: leadToRow(l) })));
  }

  async getSearch(id: string): Promise<SearchResult | null> {
    const rows = await this.readAll(SEARCHES_TAB);
    const row = rows.find((r) => r[0] === id);
    if (!row?.[2]) return null;
    try { return JSON.parse(row[2]) as SearchResult; } catch { return null; }
  }

  async saveSearch(s: SearchResult) {
    await this.upsertRows(SEARCHES_TAB, [{ id: s.id, values: [s.id, s.updatedAt, JSON.stringify(s)] }]);
  }
}

function describe(data: unknown): string {
  const msg = (data as { error?: { message?: string } } | null)?.error?.message;
  return msg ? `: ${msg}` : "";
}

export function sheetsConfigured(env: NodeJS.ProcessEnv = process.env): boolean {
  return !!env.GOOGLE_SHEETS_ID && (!!env.GOOGLE_SERVICE_ACCOUNT_JSON || (!!env.GOOGLE_SERVICE_ACCOUNT_EMAIL && !!env.GOOGLE_PRIVATE_KEY));
}

export function createSheetsStoreFromEnv(env: NodeJS.ProcessEnv = process.env): SheetsStore {
  const spreadsheetId = env.GOOGLE_SHEETS_ID!;
  let email = env.GOOGLE_SERVICE_ACCOUNT_EMAIL;
  let key = env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g, "\n");
  if (env.GOOGLE_SERVICE_ACCOUNT_JSON) {
    const j = JSON.parse(env.GOOGLE_SERVICE_ACCOUNT_JSON) as { client_email: string; private_key: string };
    email = j.client_email;
    key = j.private_key;
  }
  const client = new JWT({ email, key, scopes: ["https://www.googleapis.com/auth/spreadsheets"] });
  const transport: SheetsTransport = async (req) => {
    const url = new URL(`https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(spreadsheetId)}${req.path}`);
    for (const [k, v] of Object.entries(req.query ?? {})) url.searchParams.set(k, v);
    const res = await client.request({ url: url.toString(), method: req.method, data: req.body, validateStatus: () => true });
    return { status: res.status, data: res.data };
  };
  return new SheetsStore({ spreadsheetId, transport });
}
