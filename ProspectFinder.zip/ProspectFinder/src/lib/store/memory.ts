import type { Lead, SearchResult } from "../types";
import type { LeadStore, UpsertSummary } from "./types";

/** Armazenamento volátil: perde tudo ao reiniciar. Nunca apresentado como persistência. */
export class MemoryStore implements LeadStore {
  kind = "memoria" as const;
  persistent = false;
  private leads = new Map<string, Lead>();
  private searches = new Map<string, SearchResult>();

  async listLeads() { return [...this.leads.values()].map((l) => structuredClone(l)); }
  async getLead(id: string) { const l = this.leads.get(id); return l ? structuredClone(l) : null; }
  async upsertLeads(leads: Lead[]): Promise<UpsertSummary> {
    let inserted = 0, updated = 0;
    for (const l of leads) {
      if (this.leads.has(l.id)) updated++; else inserted++;
      this.leads.set(l.id, structuredClone(l));
    }
    return { inserted, updated };
  }
  async getSearch(id: string) { const s = this.searches.get(id); return s ? structuredClone(s) : null; }
  async saveSearch(s: SearchResult) { this.searches.set(s.id, structuredClone(s)); }
}
