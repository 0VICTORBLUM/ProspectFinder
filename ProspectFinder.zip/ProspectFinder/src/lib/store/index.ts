import { MemoryStore } from "./memory";
import { createSheetsStoreFromEnv, sheetsConfigured } from "./sheets";
import type { LeadStore } from "./types";

const g = globalThis as unknown as { __pfStore?: LeadStore };

export function getStore(): LeadStore {
  if (!g.__pfStore) {
    g.__pfStore = sheetsConfigured() ? createSheetsStoreFromEnv() : new MemoryStore();
  }
  return g.__pfStore;
}

export function setStoreForTests(store: LeadStore | undefined) {
  g.__pfStore = store;
}
