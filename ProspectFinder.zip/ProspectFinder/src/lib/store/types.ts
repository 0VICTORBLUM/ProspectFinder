import type { Lead, SearchResult } from "../types";

export interface UpsertSummary {
  inserted: number;
  updated: number;
}

export interface LeadStore {
  kind: "sheets" | "memoria";
  /** Verdadeiro somente se os dados sobrevivem a reinícios (Google Sheets). */
  persistent: boolean;
  listLeads(): Promise<Lead[]>;
  getLead(id: string): Promise<Lead | null>;
  /** Idempotente: ids existentes são atualizados, novos são inseridos. */
  upsertLeads(leads: Lead[]): Promise<UpsertSummary>;
  getSearch(id: string): Promise<SearchResult | null>;
  saveSearch(search: SearchResult): Promise<void>;
}

export class StoreError extends Error {
  constructor(message: string, public readonly retryable: boolean, public readonly status?: number) {
    super(message);
    this.name = "StoreError";
  }
}
