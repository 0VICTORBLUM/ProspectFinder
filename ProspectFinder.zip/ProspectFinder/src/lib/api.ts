import { NextResponse } from "next/server";
import { authorize } from "./auth";
import { clientKey, rateLimit } from "./rate-limit";

export function jsonError(status: number, message: string, details?: string[]) {
  return NextResponse.json({ error: message, ...(details ? { details } : {}) }, { status });
}

/** Autenticação + limite de requisições. Retorna uma resposta de erro ou null se liberado. */
export async function guard(req: Request, opts: { max?: number; windowMs?: number; bucket?: string } = {}): Promise<NextResponse | null> {
  const auth = await authorize(req);
  if (!auth.ok) return jsonError(auth.status, auth.message);
  const rl = rateLimit(`${opts.bucket ?? "api"}:${clientKey(req)}`, opts.max ?? 240, opts.windowMs ?? 60_000);
  if (!rl.ok) {
    const res = jsonError(429, "Muitas requisições. Aguarde um instante e tente novamente.");
    res.headers.set("retry-after", String(Math.ceil(rl.retryAfterMs / 1000)));
    return res;
  }
  return null;
}

const MAX_BODY = 32_000;

export async function readJson(req: Request): Promise<{ ok: true; data: unknown } | { ok: false; res: NextResponse }> {
  const text = await req.text();
  if (text.length > MAX_BODY) return { ok: false, res: jsonError(413, "Requisição grande demais.") };
  try {
    return { ok: true, data: JSON.parse(text || "{}") };
  } catch {
    return { ok: false, res: jsonError(400, "JSON inválido.") };
  }
}

export const ID_PATTERN = /^[A-Za-z0-9-]{3,64}$/;
