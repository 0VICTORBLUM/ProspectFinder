import { SEGMENTS } from "./segments";
import { normalizeCnae, stripAccentsLower } from "./normalize";
import type { Lead, QualificationResult, ScoreCriterion, SegmentId, Uf } from "./types";

/** Pesos configuráveis; somam 100. */
export interface ScoreWeights {
  cnaePrincipal: number;
  cnaeSecundario: number; // exclusivo com cnaePrincipal
  nomeComPalavraChave: number;
  evidenciaNoSite: number;
  regiao: number;
  websiteOficial: number;
  telefone: number;
  canal: number;
}

export const DEFAULT_WEIGHTS: ScoreWeights = {
  cnaePrincipal: 40,
  cnaeSecundario: 20,
  nomeComPalavraChave: 10,
  evidenciaNoSite: 20,
  regiao: 10,
  websiteOficial: 5,
  telefone: 5,
  canal: 10,
};

export interface ScoreContext {
  segment: SegmentId;
  /** UFs desejadas; vazio ou ["BR"] = qualquer. */
  targetUfs?: (Uf | "BR")[];
  extraCnaes?: string[];
  extraKeywords?: string[];
  weights?: ScoreWeights;
}

type ScorableLead = Pick<
  Lead,
  | "razaoSocial" | "nomeFantasia" | "cnaePrincipal" | "cnaesSecundarios" | "uf"
  | "website" | "phone" | "provenance" | "siteEvidence"
>;

const crit = (
  id: string, label: string, max: number, status: ScoreCriterion["status"], detail: string,
): ScoreCriterion => ({ id, label, max, status, points: status === "met" ? max : 0, detail });

export function qualify(lead: ScorableLead, ctx: ScoreContext): QualificationResult {
  const seg = SEGMENTS[ctx.segment];
  const w = ctx.weights ?? DEFAULT_WEIGHTS;
  const catalogCnaes = new Set([...seg.cnaes.filter((c) => c.role === "principal").map((c) => c.code), ...(ctx.extraCnaes ?? [])]);
  const relatedCnaes = new Set(seg.cnaes.map((c) => c.code));
  const keywords = [...seg.keywords, ...(ctx.extraKeywords ?? []).map(stripAccentsLower)];
  const principal = normalizeCnae(lead.cnaePrincipal);
  const secondary = lead.cnaesSecundarios.map(normalizeCnae).filter((c): c is string => !!c);
  const breakdown: ScoreCriterion[] = [];

  // 1. CNAE principal / secundário (exclusivos)
  if (!principal && secondary.length === 0) {
    breakdown.push(crit("cnae", "CNAE compatível com o segmento", w.cnaePrincipal, "unknown", "CNAE não informado pela fonte."));
  } else if (principal && (catalogCnaes.has(principal) || relatedCnaes.has(principal))) {
    breakdown.push(crit("cnae", "CNAE principal compatível", w.cnaePrincipal, "met", `CNAE principal ${principal} consta no catálogo do segmento.`));
  } else if (secondary.some((c) => catalogCnaes.has(c) || relatedCnaes.has(c))) {
    breakdown.push({ ...crit("cnae", "CNAE secundário compatível", w.cnaeSecundario, "met", "Atividade secundária consta no catálogo do segmento."), });
  } else {
    breakdown.push(crit("cnae", "CNAE compatível com o segmento", w.cnaePrincipal, "unmet", "Nenhum CNAE da empresa consta no catálogo do segmento."));
  }

  // 2. Nome com palavra-chave (peso baixo: nome sozinho não define especialização)
  const nameText = stripAccentsLower(`${lead.razaoSocial} ${lead.nomeFantasia ?? ""}`);
  const nameHit = keywords.find((k) => nameText.includes(stripAccentsLower(k)));
  breakdown.push(
    crit("nome", "Nome com termo do segmento", w.nomeComPalavraChave, nameHit ? "met" : "unmet",
      nameHit ? `O nome contém "${nameHit}" (indício fraco isoladamente).` : "Nenhum termo do segmento no nome."),
  );

  // 3. Evidência em site oficial verificado
  const siteVerified = lead.provenance["website"]?.confidence === "verified";
  if (lead.siteEvidence.length === 0) {
    breakdown.push(crit("site", "Evidência de serviços/produtos no site", w.evidenciaNoSite, "unknown",
      "Enriquecimento não executado ou sem conteúdo útil."));
  } else {
    const hit = lead.siteEvidence.find((e) => keywords.some((k) => stripAccentsLower(e).includes(stripAccentsLower(k))));
    breakdown.push(
      crit("site", "Evidência de serviços/produtos no site", w.evidenciaNoSite, hit && siteVerified ? "met" : "unmet",
        hit ? (siteVerified ? "Site confirmado menciona termos do segmento." : "Site ainda não confirmado como da empresa; não pontuado.") : "Site sem termos do segmento."),
    );
  }

  // 4. Região
  const targets = ctx.targetUfs ?? [];
  if (!lead.uf) breakdown.push(crit("regiao", "Dentro da região desejada", w.regiao, "unknown", "UF não informada."));
  else if (targets.length === 0 || targets.includes("BR")) breakdown.push(crit("regiao", "Dentro da região desejada", w.regiao, "met", "Pesquisa sem restrição de estado."));
  else breakdown.push(crit("regiao", "Dentro da região desejada", w.regiao, targets.includes(lead.uf) ? "met" : "unmet", `UF ${lead.uf}.`));

  // 5. Website oficial (somente quando verificado)
  if (!lead.website) breakdown.push(crit("website", "Website oficial confirmado", w.websiteOficial, "unknown", "Sem website conhecido."));
  else breakdown.push(crit("website", "Website oficial confirmado", w.websiteOficial, siteVerified ? "met" : "unmet",
    siteVerified ? "Website confirmado." : "Website apenas inferido; precisa de confirmação."));

  // 6. Telefone (contatabilidade, não qualidade comercial)
  breakdown.push(crit("telefone", "Telefone comercial disponível", w.telefone, lead.phone ? "met" : "unknown",
    lead.phone ? "Telefone informado (indica contatabilidade, não qualidade do lead)." : "Telefone não informado."));

  // 7. Canal (revenda/distribuição)
  if (seg.channel) {
    const principalIsChannel = principal ? seg.cnaes.some((c) => c.code === principal) : false;
    breakdown.push(crit("canal", "Atua como revenda/distribuição", w.canal, principal ? (principalIsChannel ? "met" : "unmet") : "unknown",
      principalIsChannel ? "CNAE principal é de comércio de materiais." : "Sem evidência de atuação como canal."));
  } else {
    breakdown.push(crit("canal", "Atua como revenda/distribuição", w.canal, "unknown", "Não aplicável ao segmento (sem pontuação)."));
  }

  const final = breakdown.map((b) => ({ ...b, points: b.status === "met" ? b.max : 0 }));
  const score = Math.min(100, final.reduce((a, b) => a + b.points, 0));
  return { score, breakdown: final };
}
