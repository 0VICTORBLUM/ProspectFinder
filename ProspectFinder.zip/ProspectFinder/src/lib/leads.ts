import { createHash } from "node:crypto";
import {
  isValidCnpj, normalizeCity, normalizeCnae, normalizeCnpj, normalizeCompanyName, normalizePhone,
  normalizeUf, normalizeWebsite, websiteHost,
} from "./normalize";
import type { Confidence, FieldProvenance, Lead, RawCompany, SegmentId } from "./types";

export function leadId(raw: { cnpj: string | null; razaoSocial: string; uf: string | null; city: string | null; isDemo?: boolean }): string {
  if (raw.isDemo) {
    return `demo-${createHash("sha1").update(`${normalizeCompanyName(raw.razaoSocial)}|${raw.uf}|${normalizeCity(raw.city)}`).digest("hex").slice(0, 12)}`;
  }
  if (raw.cnpj) return `cnpj-${raw.cnpj}`;
  const key = `${normalizeCompanyName(raw.razaoSocial)}|${raw.uf ?? ""}|${normalizeCity(raw.city)}`;
  return `nm-${createHash("sha1").update(key).digest("hex").slice(0, 16)}`;
}

export type BuildResult =
  | { ok: true; lead: Lead }
  | { ok: false; reason: "cnpj_invalido" | "sem_nome" };

/** Converte um registro bruto em Lead normalizado, sem pontuação (preenchida depois). */
export function buildLead(raw: RawCompany, segment: SegmentId, searchId: string | null, now = new Date().toISOString()): BuildResult {
  if (!raw.razaoSocial?.trim()) return { ok: false, reason: "sem_nome" };
  const cnpj = normalizeCnpj(raw.cnpj);
  if (raw.cnpj && !raw.isDemo && !isValidCnpj(raw.cnpj)) return { ok: false, reason: "cnpj_invalido" };
  const uf = normalizeUf(raw.uf);
  const phone = normalizePhone(raw.phone, raw.ddd);
  const website = normalizeWebsite(raw.website);
  const email = raw.email?.trim().toLowerCase() || null;
  const verified: Confidence = raw.isDemo ? "inferred" : "verified";
  const prov = (confidence: Confidence = verified): FieldProvenance => ({
    source: raw.source, confidence, updatedAt: now, ...(raw.sourceUrl ? { url: raw.sourceUrl } : {}),
  });
  const provenance: Record<string, FieldProvenance> = {};
  if (cnpj) provenance["cnpj"] = prov();
  if (phone) provenance["phone"] = prov();
  if (email) provenance["email"] = prov();
  if (website) provenance["website"] = prov(raw.websiteInferred ? "inferred" : verified);
  if (raw.cnaePrincipal) provenance["cnae"] = prov();

  const base = {
    cnpj,
    razaoSocial: raw.razaoSocial.trim(),
    uf,
    city: raw.city?.trim() || null,
    isDemo: !!raw.isDemo,
  };
  return {
    ok: true,
    lead: {
      id: leadId(base),
      cnpj,
      razaoSocial: base.razaoSocial,
      nomeFantasia: raw.nomeFantasia?.trim() || null,
      segment,
      city: base.city,
      uf,
      phone: phone?.formatted ?? null,
      email,
      website,
      cnaePrincipal: normalizeCnae(raw.cnaePrincipal),
      cnaesSecundarios: (raw.cnaesSecundarios ?? []).map(normalizeCnae).filter((c): c is string => !!c),
      situacaoCadastral: raw.situacaoCadastral ?? null,
      matriz: raw.matriz ?? null,
      score: 0,
      scoreBreakdown: [],
      sources: [raw.source],
      sourceUrl: raw.sourceUrl ?? null,
      provenance,
      discoveredAt: now,
      updatedAt: now,
      status: "novo",
      notes: "",
      isDemo: !!raw.isDemo,
      searchId,
      siteEvidence: [],
    },
  };
}

/** Procura duplicata: CNPJ → host do website → nome normalizado + UF + cidade (igualdade exata). */
export function findDuplicate(lead: Lead, existing: Lead[]): Lead | undefined {
  const host = websiteHost(lead.website);
  const name = normalizeCompanyName(lead.razaoSocial);
  const city = normalizeCity(lead.city);
  return existing.find((e) => {
    if (e.id === lead.id) return true;
    if (lead.cnpj && e.cnpj) return lead.cnpj === e.cnpj;
    if (e.isDemo !== lead.isDemo) return false;
    // Sem CNPJ em um dos lados: o website só vale quando o nome também bate (evita fundir filiais/homônimos).
    const sameName = normalizeCompanyName(e.razaoSocial) === name && !!name;
    if (host && websiteHost(e.website) === host && sameName) return true;
    return sameName && e.uf === lead.uf && normalizeCity(e.city) === city && !!city;
  });
}

const FILLABLE = ["nomeFantasia", "city", "uf", "phone", "email", "website", "cnaePrincipal", "situacaoCadastral", "matriz", "sourceUrl", "cnpj"] as const;

/** Mescla sem apagar dado válido: o existente prevalece; o novo só preenche vazios. Campos comerciais ficam do existente. */
export function mergeLeads(existing: Lead, incoming: Lead): Lead {
  const merged: Lead = { ...existing };
  const m = merged as unknown as Record<string, unknown>;
  const inc = incoming as unknown as Record<string, unknown>;
  const prov = { ...existing.provenance };
  for (const f of FILLABLE) {
    if (m[f] === null || m[f] === undefined || m[f] === "") {
      if (inc[f] !== null && inc[f] !== undefined && inc[f] !== "") {
        m[f] = inc[f];
        const key = f === "cnaePrincipal" ? "cnae" : f;
        const p = incoming.provenance[key];
        if (p) prov[key] = p;
      }
    } else {
      // Se o existente era inferido e o novo é verificado para o mesmo valor, promove.
      const key = f === "cnaePrincipal" ? "cnae" : f;
      const pi = incoming.provenance[key];
      if (pi?.confidence === "verified" && prov[key]?.confidence === "inferred" && m[f] === inc[f]) prov[key] = pi;
    }
  }
  merged.cnaesSecundarios = [...new Set([...existing.cnaesSecundarios, ...incoming.cnaesSecundarios])];
  merged.sources = [...new Set([...existing.sources, ...incoming.sources])];
  merged.siteEvidence = [...new Set([...existing.siteEvidence, ...incoming.siteEvidence])];
  merged.provenance = prov;
  merged.updatedAt = incoming.updatedAt;
  return merged;
}
