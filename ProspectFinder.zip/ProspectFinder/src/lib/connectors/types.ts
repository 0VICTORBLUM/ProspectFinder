import type { DataSource, RawCompany, SearchRequest, SegmentId, SourceAvailability } from "../types";

export interface ConnectorQuery {
  segment: SegmentId;
  request: SearchRequest;
  /** CNAEs (7 dígitos) a considerar: catálogo do segmento + extras do usuário. */
  cnaes: string[];
  /** Palavras-chave normalizadas (sem acento, minúsculas). */
  keywords: string[];
  cursor: number;
  batchSize: number;
  /** Timestamp (ms) limite para o lote. */
  deadline: number;
}

export interface ConnectorPage {
  records: RawCompany[];
  nextCursor: number;
  done: boolean;
  scanned: number;
}

export interface Connector {
  meta: DataSource;
  availability(): Promise<SourceAvailability>;
  search(q: ConnectorQuery): Promise<ConnectorPage>;
}

export class ConnectorError extends Error {
  constructor(message: string, public readonly sourceId: string, public readonly retryable = false) {
    super(message);
    this.name = "ConnectorError";
  }
}
