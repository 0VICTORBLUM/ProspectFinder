import { normalizeCity, stripAccentsLower } from "../normalize";
import type { RawCompany } from "../types";
import type { Connector, ConnectorPage, ConnectorQuery } from "./types";

/** DADOS FICTÍCIOS. Nenhuma destas empresas existe; nomes, telefones e e-mails são inventados para demonstração. */
const F = (
  n: string, fantasia: string, city: string, uf: string, cnae: string, ddd: string, phone: string, sec: string[] = [],
): RawCompany => ({
  razaoSocial: `DEMO ${n} LTDA`,
  nomeFantasia: `[Demonstração] ${fantasia}`,
  city, uf, ddd, phone,
  email: `contato@demo-${stripAccentsLower(fantasia).replace(/[^a-z0-9]+/g, "-")}.example.com`,
  cnaePrincipal: cnae,
  cnaesSecundarios: sec,
  situacaoCadastral: "Ativa",
  matriz: true,
  source: "demo",
  isDemo: true,
});

export const DEMO_COMPANIES: RawCompany[] = [
  F("IMPERMEABILIZACOES ALFA", "Impermeabilizações Alfa", "Curitiba", "PR", "4330401", "41", "30000001"),
  F("MANTAS BETA", "Mantas Beta Impermeabilização", "Londrina", "PR", "4330401", "43", "30000002"),
  F("INFILTRACAO ZERO", "Infiltração Zero", "Maringá", "PR", "4399199", "44", "30000003", ["4330401"]),
  F("PISCINAS E LAJES GAMA", "Gama Lajes e Piscinas", "Joinville", "SC", "4330401", "47", "30000004"),
  F("SISTEMAS DELTA", "Delta Sistemas Impermeabilizantes", "Florianópolis", "SC", "4330401", "48", "30000005"),
  F("RESERVATORIOS EPSILON", "Epsilon Reservatórios", "Blumenau", "SC", "4330401", "47", "930000006"),
  F("OBRAS ZETA", "Zeta Impermeabiliza", "São Paulo", "SP", "4330401", "11", "30000007"),
  F("MEMBRANAS ETA", "Eta Membranas", "Campinas", "SP", "4330401", "19", "30000008"),
  F("TRATAMENTO TETA", "Teta Tratamento de Infiltrações", "Ribeirão Preto", "SP", "4399199", "16", "30000009", ["4330401"]),
  F("MANTA IOTA", "Iota Manta Asfáltica", "Santos", "SP", "4330401", "13", "30000010"),
  F("DRYWALL KAPPA", "Kappa Drywall", "Curitiba", "PR", "4330403", "41", "30000011"),
  F("GESSO LAMBDA", "Lambda Gesso Acartonado", "Cascavel", "PR", "4330403", "45", "30000012"),
  F("STEEL FRAME MI", "Mi Steel Frame", "Itajaí", "SC", "4330499", "47", "30000013"),
  F("FORROS NI", "Ni Forros e Divisórias", "Chapecó", "SC", "4330402", "49", "30000014"),
  F("DIVISORIAS XI", "Xi Divisórias", "São Paulo", "SP", "4330402", "11", "30000015"),
  F("GESSO OMICRON", "Omicron Gesso", "Sorocaba", "SP", "4330403", "15", "30000016"),
  F("LIGHT STEEL PI", "Pi Light Steel Framing", "Campinas", "SP", "4330499", "19", "30000017"),
  F("DRYWALL RO", "Ro Drywall e Acabamentos", "Guarulhos", "SP", "4330403", "11", "30000018"),
  F("CONSTRUTORA SIGMA", "Sigma Construtora", "Curitiba", "PR", "4120400", "41", "30000019"),
  F("EMPREITEIRA TAU", "Tau Empreiteira", "Joinville", "SC", "4120400", "47", "30000020"),
  F("DISTRIBUIDORA UPSILON", "Upsilon Materiais", "Londrina", "PR", "4679699", "43", "30000021"),
  F("REVENDA FI", "Fi Materiais de Construção", "São José", "SC", "4744099", "48", "30000022"),
  F("DEPOSITO QUI", "Qui Depósito de Construção", "Osasco", "SP", "4744099", "11", "30000023"),
  F("ATACADO PSI", "Psi Atacado de Materiais", "Campinas", "SP", "4679699", "19", "30000024"),
];

export const demoConnector: Connector = {
  meta: {
    id: "demo",
    label: "Dados de demonstração (fictícios)",
    description: "Empresas inventadas, apenas para testar a interface. Nunca use como lead real.",
    demo: true,
  },
  async availability() {
    return process.env.ENABLE_DEMO_SOURCE === "false"
      ? { state: "unavailable", reason: "Fonte de demonstração desabilitada (ENABLE_DEMO_SOURCE=false)." }
      : { state: "available" };
  },
  async search(q: ConnectorQuery): Promise<ConnectorPage> {
    const cnaeSet = new Set(q.cnaes);
    const cities = q.request.cities.map(normalizeCity);
    const matches = DEMO_COMPANIES.filter((c) => {
      if (q.request.uf !== "BR" && c.uf !== q.request.uf) return false;
      if (cities.length && !cities.includes(normalizeCity(c.city))) return false;
      const name = stripAccentsLower(`${c.razaoSocial} ${c.nomeFantasia ?? ""}`);
      return cnaeSet.has(c.cnaePrincipal ?? "") || (c.cnaesSecundarios ?? []).some((x) => cnaeSet.has(x)) || q.keywords.some((k) => name.includes(k));
    });
    const slice = matches.slice(q.cursor, q.cursor + q.batchSize);
    const next = q.cursor + slice.length;
    return { records: slice, nextCursor: next, done: next >= matches.length, scanned: slice.length };
  },
};
