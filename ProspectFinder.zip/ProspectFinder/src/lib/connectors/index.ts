import { cnpjLocalConnector } from "./cnpj-local";
import { demoConnector } from "./demo";
import type { Connector } from "./types";
import type { SourceId } from "../types";

/** Registre novos conectores aqui. Cada um é independente e implementa `Connector`. */
export const CONNECTORS: Partial<Record<SourceId, Connector>> = {
  "cnpj-local": cnpjLocalConnector,
  demo: demoConnector,
};

export function getConnector(id: SourceId): Connector | undefined {
  return CONNECTORS[id];
}
