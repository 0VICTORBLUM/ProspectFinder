import { promises as fs } from "node:fs";
import path from "node:path";
import { normalizeCity, normalizeCnae, stripAccentsLower } from "../normalize";
import type { RawCompany } from "../types";
import { ConnectorError, type Connector, type ConnectorPage, type ConnectorQuery } from "./types";

export const CNPJ_PORTAL_URL = "https://dados.gov.br/dados/conjuntos-dados/cadastro-nacional-da-pessoa-juridica---cnpj";

/** Linha do arquivo JSONL gerado por `npm run import:cnpj`. */
export interface CnpjRecord {
  cnpj: string;
  razaoSocial: string;
  nomeFantasia: string | null;
  situacao: string; // código RFB: 01, 02, 03, 04, 08
  matriz: boolean;
  cnaePrincipal: string;
  cnaesSecundarios: string[];
  uf: string;
  city: string;
  ddd: string | null;
  phone: string | null;
  email: string | null;
}

export const SITUACAO_LABEL: Record<string, string> = {
  "01": "Nula", "02": "Ativa", "03": "Suspensa", "04": "Inapta", "08": "Baixada",
};

export function dataFilePath(): string {
  return path.resolve(process.cwd(), process.env.CNPJ_DATA_FILE ?? "data/cnpj/empresas.jsonl");
}

export function matchesQuery(r: CnpjRecord, q: ConnectorQuery): boolean {
  const req = q.request;
  if (req.uf !== "BR" && r.uf !== req.uf) return false;
  if (req.cities.length) {
    const cities = req.cities.map(normalizeCity);
    if (!cities.includes(normalizeCity(r.city))) return false;
  }
  if (req.situacao === "ativa" && r.situacao !== "02") return false;
  if (req.estabelecimento === "matriz" && !r.matriz) return false;
  const cnaeSet = new Set(q.cnaes);
  const cnaeHit =
    cnaeSet.has(normalizeCnae(r.cnaePrincipal) ?? "") ||
    r.cnaesSecundarios.some((c) => cnaeSet.has(normalizeCnae(c) ?? ""));
  const name = stripAccentsLower(`${r.razaoSocial} ${r.nomeFantasia ?? ""}`);
  const keywordHit = q.keywords.some((k) => name.includes(k));
  return cnaeHit || keywordHit;
}

export function toRaw(r: CnpjRecord): RawCompany {
  return {
    cnpj: r.cnpj,
    razaoSocial: r.razaoSocial,
    nomeFantasia: r.nomeFantasia,
    city: r.city,
    uf: r.uf,
    ddd: r.ddd,
    phone: r.phone,
    email: r.email,
    cnaePrincipal: r.cnaePrincipal,
    cnaesSecundarios: r.cnaesSecundarios,
    situacaoCadastral: SITUACAO_LABEL[r.situacao] ?? r.situacao,
    matriz: r.matriz,
    sourceUrl: CNPJ_PORTAL_URL,
    source: "cnpj-local",
  };
}

const CHUNK = 256 * 1024;

export const cnpjLocalConnector: Connector = {
  meta: {
    id: "cnpj-local",
    label: "Dados Abertos do CNPJ (arquivo local filtrado)",
    description: "Receita Federal, via arquivo JSONL gerado pelo script de importação.",
    demo: false,
  },

  async availability() {
    try {
      const st = await fs.stat(dataFilePath());
      if (st.size === 0) return { state: "unavailable", reason: "O arquivo de dados do CNPJ está vazio. Rode `npm run import:cnpj`." };
      return { state: "available" };
    } catch {
      return {
        state: "unavailable",
        reason: "Arquivo de dados do CNPJ não encontrado. Gere-o com `npm run import:cnpj` (veja o README) e defina CNPJ_DATA_FILE.",
      };
    }
  },

  /** cursor = deslocamento em bytes no arquivo. */
  async search(q: ConnectorQuery): Promise<ConnectorPage> {
    let handle: fs.FileHandle;
    try {
      handle = await fs.open(dataFilePath(), "r");
    } catch {
      throw new ConnectorError("Arquivo de dados do CNPJ indisponível.", "cnpj-local");
    }
    const records: RawCompany[] = [];
    let offset = q.cursor;
    let scanned = 0;
    let carry: Buffer = Buffer.alloc(0);
    try {
      const size = (await handle.stat()).size;
      let eof = offset >= size;
      outer: while (!eof) {
        const buf = Buffer.alloc(CHUNK);
        const { bytesRead } = await handle.read(buf, 0, CHUNK, offset + carry.length);
        if (bytesRead === 0) { eof = true; break; }
        let data: Buffer = Buffer.concat([carry, buf.subarray(0, bytesRead)]);
        let start = 0;
        for (;;) {
          const nl = data.indexOf(0x0a, start);
          if (nl === -1) break;
          const line = data.subarray(start, nl).toString("utf8").trim();
          start = nl + 1;
          if (line) {
            scanned++;
            try {
              const rec = JSON.parse(line) as CnpjRecord;
              if (matchesQuery(rec, q)) records.push(toRaw(rec));
            } catch {
              // linha corrompida: ignora (contabilizada como escaneada)
            }
          }
          if (records.length >= q.batchSize || Date.now() >= q.deadline) {
            offset += start;
            carry = Buffer.alloc(0);
            break outer;
          }
        }
        offset += start;
        carry = data.subarray(start);
        if (offset + carry.length >= size && carry.length === 0) eof = true;
        if (bytesRead < CHUNK) {
          // último pedaço: trata resto sem newline final
          const tail = carry.toString("utf8").trim();
          if (tail) {
            scanned++;
            try {
              const rec = JSON.parse(tail) as CnpjRecord;
              if (matchesQuery(rec, q)) records.push(toRaw(rec));
            } catch { /* ignora */ }
          }
          offset = size;
          eof = true;
        }
      }
      return { records, nextCursor: offset, done: offset >= size, scanned };
    } finally {
      await handle.close();
    }
  },
};
