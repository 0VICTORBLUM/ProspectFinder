export const SEGMENT_IDS = [
  "impermeabilizacao",
  "construcao_a_seco",
  "construtoras",
  "distribuidores",
  "outro",
] as const;
export type SegmentId = (typeof SEGMENT_IDS)[number];

export const UFS = [
  "AC","AL","AP","AM","BA","CE","DF","ES","GO","MA","MT","MS","MG","PA",
  "PB","PR","PE","PI","RJ","RN","RS","RO","RR","SC","SP","SE","TO",
] as const;
export type Uf = (typeof UFS)[number];

export const LEAD_STATUSES = [
  "novo",
  "em_analise",
  "contato_pendente",
  "contatado",
  "qualificado",
  "descartado",
] as const;
export type LeadStatus = (typeof LEAD_STATUSES)[number];

export const STATUS_LABELS: Record<LeadStatus, string> = {
  novo: "Novo",
  em_analise: "Em análise",
  contato_pendente: "Contato pendente",
  contatado: "Contatado",
  qualificado: "Qualificado",
  descartado: "Descartado",
};

export type SourceId = "cnpj-local" | "website" | "demo";

export interface DataSource {
  id: SourceId;
  label: string;
  description: string;
  /** Verdadeiro quando a fonte devolve dados fictícios. */
  demo: boolean;
}

export type SourceAvailability =
  | { state: "available" }
  | { state: "unavailable"; reason: string };

/** "verified": veio diretamente da fonte oficial. "inferred": deduzido, precisa de confirmação. */
export type Confidence = "verified" | "inferred";

export interface FieldProvenance {
  source: SourceId;
  confidence: Confidence;
  updatedAt: string;
  url?: string;
}

export interface ScoreCriterion {
  id: string;
  label: string;
  points: number;
  max: number;
  status: "met" | "unmet" | "unknown";
  detail: string;
}

export interface QualificationResult {
  score: number;
  breakdown: ScoreCriterion[];
}

export interface Lead {
  id: string;
  cnpj: string | null;
  razaoSocial: string;
  nomeFantasia: string | null;
  segment: SegmentId;
  city: string | null;
  uf: Uf | null;
  phone: string | null;
  email: string | null;
  website: string | null;
  cnaePrincipal: string | null;
  cnaesSecundarios: string[];
  situacaoCadastral: string | null;
  matriz: boolean | null;
  score: number;
  scoreBreakdown: ScoreCriterion[];
  sources: SourceId[];
  sourceUrl: string | null;
  provenance: Record<string, FieldProvenance>;
  discoveredAt: string;
  updatedAt: string;
  status: LeadStatus;
  notes: string;
  isDemo: boolean;
  searchId: string | null;
  /** Texto público extraído de sites oficiais (enriquecimento), usado só na pontuação. */
  siteEvidence: string[];
}

/** Registro bruto devolvido por um conector, antes da normalização. */
export interface RawCompany {
  cnpj?: string | null;
  razaoSocial: string;
  nomeFantasia?: string | null;
  city?: string | null;
  uf?: string | null;
  ddd?: string | null;
  phone?: string | null;
  email?: string | null;
  website?: string | null;
  cnaePrincipal?: string | null;
  cnaesSecundarios?: string[];
  situacaoCadastral?: string | null;
  matriz?: boolean | null;
  sourceUrl?: string | null;
  source: SourceId;
  isDemo?: boolean;
  /** Se o website foi apenas deduzido (ex.: domínio do e-mail corporativo). */
  websiteInferred?: boolean;
}

export type SearchMode = "manual" | "strategy";

export interface SearchRequest {
  mode: SearchMode;
  segment: SegmentId;
  split: { impermeabilizacao: number; construcao_a_seco: number };
  uf: Uf | "BR";
  cities: string[];
  keywords: string[];
  cnaes: string[];
  situacao: "ativa" | "todas";
  estabelecimento: "matriz" | "todos";
  limit: number;
  sources: SourceId[];
  enrich: boolean;
}

export type SearchStatus =
  | "pendente"
  | "em_andamento"
  | "concluida"
  | "parcial"
  | "erro"
  | "cancelada";

export interface SearchTask {
  segment: SegmentId;
  target: number;
  saved: number;
  /** Posição de leitura por fonte (cada conector define o significado). */
  cursors: Partial<Record<SourceId, number>>;
  doneSources: SourceId[];
  done: boolean;
}

export interface SearchCounts {
  scanned: number;
  found: number;
  saved: number;
  duplicates: number;
  discarded: number;
}

export interface SearchResult {
  id: string;
  request: SearchRequest;
  status: SearchStatus;
  /** "real": só fontes reais; "demonstracao": só dados fictícios; "misto": ambos. */
  dataMode: "real" | "demonstracao" | "misto";
  tasks: SearchTask[];
  taskIndex: number;
  counts: SearchCounts;
  warnings: string[];
  errors: string[];
  sourceStatus: Partial<Record<SourceId, SourceAvailability>>;
  persistence: "sheets" | "memoria";
  createdAt: string;
  updatedAt: string;
  discardReasons: Record<string, number>;
}
