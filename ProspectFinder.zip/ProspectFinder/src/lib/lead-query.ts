import { normalizeCity } from "./normalize";
import { paginate, type Page } from "./paginate";
import { searchTerm, type LeadQuery } from "./validation";
import { SEGMENT_LABELS } from "./segments";
import { STATUS_LABELS, type Lead } from "./types";
import { formatCnae, formatCnpj } from "./normalize";

export function filterLeads(leads: Lead[], q: LeadQuery): Lead[] {
  const { text, digits } = searchTerm(q.q);
  const city = q.city ? normalizeCity(q.city) : "";
  return leads.filter((l) => {
    if (q.segment && l.segment !== q.segment) return false;
    if (q.uf && l.uf !== q.uf) return false;
    if (q.status && l.status !== q.status) return false;
    if (q.searchId && l.searchId !== q.searchId) return false;
    if (city && !normalizeCity(l.city).includes(city)) return false;
    if (text) {
      const byName = `${l.razaoSocial} ${l.nomeFantasia ?? ""}`.toLowerCase().includes(text);
      const byCnpj = digits.length >= 3 && (l.cnpj ?? "").includes(digits);
      if (!byName && !byCnpj) return false;
    }
    return true;
  });
}

export function sortLeads(leads: Lead[], sort: LeadQuery["sort"], dir: LeadQuery["dir"]): Lead[] {
  const mul = dir === "asc" ? 1 : -1;
  const val = (l: Lead): string | number => {
    switch (sort) {
      case "score": return l.score;
      case "discoveredAt": return l.discoveredAt;
      case "cnpj": return l.cnpj ?? "";
      case "city": return (l.city ?? "").toLowerCase();
      case "uf": return l.uf ?? "";
      case "segment": return l.segment;
      case "status": return l.status;
      default: return l.razaoSocial.toLowerCase();
    }
  };
  return [...leads].sort((a, b) => {
    const x = val(a), y = val(b);
    if (x < y) return -1 * mul;
    if (x > y) return 1 * mul;
    return a.id.localeCompare(b.id);
  });
}

export function queryLeads(leads: Lead[], q: LeadQuery): Page<Lead> {
  return paginate(sortLeads(filterLeads(leads, q), q.sort, q.dir), q.page, q.pageSize);
}

export const EXPORT_HEADERS = [
  "Empresa", "Nome fantasia", "CNPJ", "Segmento", "Cidade", "UF", "Telefone", "E-mail", "Website", "CNAE principal",
  "Pontuação", "Origem", "Descoberto em", "Status", "Observações", "Dados fictícios",
];

export function leadToExportRow(l: Lead): unknown[] {
  return [
    l.razaoSocial, l.nomeFantasia ?? "", l.cnpj ? formatCnpj(l.cnpj) : "", SEGMENT_LABELS[l.segment], l.city ?? "", l.uf ?? "",
    l.phone ?? "", l.email ?? "", l.website ?? "", l.cnaePrincipal ? formatCnae(l.cnaePrincipal) : "", l.score,
    l.sources.join(", "), l.discoveredAt.slice(0, 10), STATUS_LABELS[l.status], l.notes, l.isDemo ? "sim" : "não",
  ];
}
