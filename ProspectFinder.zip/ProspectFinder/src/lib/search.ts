import { randomUUID } from "node:crypto";
import { getConnector } from "./connectors";
import type { Connector } from "./connectors/types";
import { allCnaesFor, SEGMENTS } from "./segments";
import { allocate } from "./distribution";
import { enrichLead, inferWebsiteFromEmail } from "./enrichment";
import { buildLead, findDuplicate, mergeLeads } from "./leads";
import { stripAccentsLower } from "./normalize";
import { qualify } from "./scoring";
import { StoreError, type LeadStore } from "./store/types";
import type { Lead, RawCompany, SearchRequest, SearchResult, SearchTask, SegmentId, SourceId } from "./types";

export interface SearchDeps {
  store: LeadStore;
  connector?: (id: SourceId) => Connector | undefined;
  enrich?: typeof enrichLead;
  now?: () => Date;
  budgetMs?: number;
}

const TERMINAL = new Set(["concluida", "parcial", "erro", "cancelada"]);
const budget = (d: SearchDeps) => d.budgetMs ?? (Number(process.env.SEARCH_STEP_BUDGET_MS) || 15000);

export function buildTasks(req: SearchRequest): SearchTask[] {
  const mk = (segment: SegmentId, target: number): SearchTask => ({ segment, target, saved: 0, cursors: {}, doneSources: [], done: false });
  if (req.mode === "manual") return [mk(req.segment, req.limit)];
  const alloc = allocate(req.limit, { impermeabilizacao: req.split.impermeabilizacao, construcao_a_seco: req.split.construcao_a_seco });
  return (Object.entries(alloc) as [SegmentId, number][]).filter(([, n]) => n > 0).map(([s, n]) => mk(s, n));
}

export async function createSearch(req: SearchRequest, deps: SearchDeps): Promise<SearchResult> {
  const now = (deps.now?.() ?? new Date()).toISOString();
  const get = deps.connector ?? getConnector;
  const sourceStatus: SearchResult["sourceStatus"] = {};
  const warnings: string[] = [];
  const active: SourceId[] = [];
  for (const id of req.sources) {
    const c = get(id);
    if (!c) { sourceStatus[id] = { state: "unavailable", reason: "Conector não registrado." }; continue; }
    const a = await c.availability();
    sourceStatus[id] = a;
    if (a.state === "available") active.push(id);
    else warnings.push(`${c.meta.label}: ${a.reason}`);
  }
  const hasDemo = active.includes("demo");
  const hasReal = active.some((s) => s !== "demo");
  const search: SearchResult = {
    id: randomUUID(),
    request: { ...req, sources: active.length ? active : req.sources },
    status: active.length ? "pendente" : "erro",
    dataMode: hasDemo && hasReal ? "misto" : hasDemo ? "demonstracao" : "real",
    tasks: buildTasks(req),
    taskIndex: 0,
    counts: { scanned: 0, found: 0, saved: 0, duplicates: 0, discarded: 0 },
    warnings,
    errors: active.length ? [] : ["Nenhuma fonte de dados disponível. Nada foi pesquisado."],
    sourceStatus,
    persistence: deps.store.kind === "sheets" ? "sheets" : "memoria",
    createdAt: now,
    updatedAt: now,
    discardReasons: {},
  };
  if (hasDemo) search.warnings.push("Esta pesquisa inclui DADOS FICTÍCIOS de demonstração. Eles não representam empresas reais.");
  if (!deps.store.persistent) search.warnings.push("Google Sheets não configurado: os leads ficam apenas em memória e serão perdidos ao reiniciar o servidor.");
  await deps.store.saveSearch(search);
  return search;
}

async function mapLimit<T, R>(items: T[], n: number, fn: (x: T) => Promise<R>): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let i = 0;
  await Promise.all(Array.from({ length: Math.min(n, items.length) }, async () => {
    while (i < items.length) { const k = i++; out[k] = await fn(items[k] as T); }
  }));
  return out;
}

export async function cancelSearch(id: string, deps: SearchDeps): Promise<SearchResult | null> {
  const s = await deps.store.getSearch(id);
  if (!s) return null;
  if (!TERMINAL.has(s.status)) {
    s.status = "cancelada";
    s.updatedAt = (deps.now?.() ?? new Date()).toISOString();
    await deps.store.saveSearch(s);
  }
  return s;
}

/** Executa UM lote dentro do orçamento de tempo. O cliente chama repetidamente até o estado ser terminal. */
export async function stepSearch(id: string, deps: SearchDeps): Promise<SearchResult | null> {
  const search = await deps.store.getSearch(id);
  if (!search) return null;
  if (TERMINAL.has(search.status)) return search;
  const get = deps.connector ?? getConnector;
  const doEnrich = deps.enrich ?? enrichLead;
  const deadline = Date.now() + budget(deps);
  const req = search.request;
  search.status = "em_andamento";

  try {
    while (search.taskIndex < search.tasks.length && Date.now() < deadline) {
      const task = search.tasks[search.taskIndex]!;
      const sources = req.sources.filter((s) => !task.doneSources.includes(s));
      if (task.saved >= task.target || sources.length === 0) {
        if (task.saved < task.target) {
          search.warnings.push(`Meta de ${SEGMENTS[task.segment].label} não atingida: ${task.saved} de ${task.target} (as fontes não têm mais empresas com esses critérios).`);
        }
        task.done = true;
        search.taskIndex++;
        continue;
      }
      const source = sources[0]!;
      const connector = get(source);
      if (!connector) { task.doneSources.push(source); continue; }

      const remaining = task.target - task.saved;
      const page = await connector.search({
        segment: task.segment,
        request: req,
        cnaes: allCnaesFor(task.segment, req.cnaes),
        keywords: [...SEGMENTS[task.segment].keywords, ...req.keywords].map(stripAccentsLower),
        cursor: task.cursors[source] ?? 0,
        batchSize: Math.min(Math.max(remaining, 10), 50),
        deadline,
      });
      task.cursors[source] = page.nextCursor;
      if (page.done) task.doneSources.push(source);
      search.counts.scanned += page.scanned;

      const built: Lead[] = [];
      for (let raw of page.records) {
        if (req.enrich && !raw.website && !raw.isDemo) {
          const w = inferWebsiteFromEmail(raw.email);
          if (w) raw = { ...raw, website: w, websiteInferred: true } as RawCompany;
        }
        const r = buildLead(raw, task.segment, search.id, (deps.now?.() ?? new Date()).toISOString());
        if (!r.ok) { search.counts.discarded++; search.discardReasons[r.reason] = (search.discardReasons[r.reason] ?? 0) + 1; continue; }
        built.push(r.lead);
      }

      let leads = built;
      if (req.enrich && built.length) {
        leads = await mapLimit(built, 3, async (l) => {
          if (l.isDemo || Date.now() >= deadline) return l;
          const out = await doEnrich(l, { segment: task.segment, extraKeywords: req.keywords });
          return out.lead;
        });
      }
      for (const l of leads) {
        const q = qualify(l, { segment: task.segment, targetUfs: [req.uf], extraCnaes: req.cnaes, extraKeywords: req.keywords });
        l.score = q.score;
        l.scoreBreakdown = q.breakdown;
      }

      const existing = await deps.store.listLeads();
      const existingIds = new Set(existing.map((e) => e.id));
      const toWrite = new Map<string, Lead>();
      const pool = [...existing];
      let queuedNew = 0;
      for (const l of leads) {
        const dup = findDuplicate(l, pool);
        if (dup) {
          const merged = mergeLeads(dup, l);
          const q = qualify(merged, { segment: merged.segment, targetUfs: [req.uf], extraCnaes: req.cnaes, extraKeywords: req.keywords });
          merged.score = q.score;
          merged.scoreBreakdown = q.breakdown;
          toWrite.set(merged.id, merged);
          pool[pool.findIndex((p) => p.id === dup.id)] = merged;
          search.counts.duplicates++;
        } else if (task.saved + queuedNew < task.target) {
          toWrite.set(l.id, l);
          pool.push(l);
          queuedNew++;
          search.counts.found++;
        }
      }
      const newOnes = [...toWrite.values()].filter((x) => !existingIds.has(x.id));
      await deps.store.upsertLeads([...toWrite.values()]);
      task.saved += newOnes.length;
      search.counts.saved += newOnes.length;
    }
    if (search.taskIndex >= search.tasks.length) {
      search.status = search.errors.length ? (search.counts.saved > 0 ? "parcial" : "erro") : "concluida";
    }
  } catch (e) {
    const msg = e instanceof StoreError ? `Falha ao gravar/ler os leads (${e.message}).` : `Falha na fonte de dados: ${(e as Error).message}`;
    search.errors.push(msg);
    search.status = search.counts.saved > 0 ? "parcial" : "erro";
  }
  search.updatedAt = (deps.now?.() ?? new Date()).toISOString();
  try {
    await deps.store.saveSearch(search);
  } catch (e) {
    search.errors.push(`Não foi possível salvar o estado da pesquisa: ${(e as Error).message}`);
    search.status = "erro";
  }
  return search;
}
