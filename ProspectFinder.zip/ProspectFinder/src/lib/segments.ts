import { SEGMENT_IDS, type SegmentId } from "./types";

export interface CnaeEntry {
  code: string; // 7 dígitos
  description: string;
  /** Peso: "principal" = atividade-núcleo do segmento; "relacionado" = apoio. */
  role: "principal" | "relacionado";
}

export interface SegmentConfig {
  id: SegmentId;
  label: string;
  /** Percentual de referência na estratégia 70/30. */
  defaultWeight: number;
  cnaes: CnaeEntry[];
  keywords: string[];
  /** Indica atuação como revenda/distribuição (usado na pontuação). */
  channel: boolean;
}

/**
 * ATENÇÃO: os códigos e descrições abaixo são pontos de partida e NÃO foram validados
 * contra a tabela oficial do IBGE/CONCLA neste ambiente. Confirme em
 * https://concla.ibge.gov.br/ antes de usá-los como critério definitivo.
 */
export const CNAE_CATALOG_VALIDATED = false;

export const SEGMENTS: Record<SegmentId, SegmentConfig> = {
  impermeabilizacao: {
    id: "impermeabilizacao",
    label: "Impermeabilização",
    defaultWeight: 70,
    channel: false,
    cnaes: [
      { code: "4330401", description: "Impermeabilização em obras de engenharia civil", role: "principal" },
    ],
    keywords: [
      "impermeabiliza", // radical: cobre impermeabilização/ões, impermeabilizadora, impermeabilizante
      "manta asfaltica",
      "membrana impermeabilizante",
      "infiltracao",
      "impermeabilizacao de lajes",
      "impermeabilizacao de piscinas",
      "impermeabilizacao de reservatorios",
    ],
  },
  construcao_a_seco: {
    id: "construcao_a_seco",
    label: "Construção a seco",
    defaultWeight: 30,
    channel: false,
    cnaes: [
      { code: "4330403", description: "Obras de acabamento em gesso e estuque", role: "principal" },
      { code: "4330402", description: "Instalação de portas, janelas, tetos, divisórias e armários embutidos", role: "relacionado" },
      { code: "4330499", description: "Outras obras de acabamento da construção", role: "relacionado" },
    ],
    keywords: [
      "drywall",
      "gesso acartonado",
      "construcao a seco",
      "steel frame",
      "light steel framing",
      "forro",
      "divisoria",
      "estrutura metalica leve",
    ],
  },
  construtoras: {
    id: "construtoras",
    label: "Construtoras e empreiteiras",
    defaultWeight: 0,
    channel: false,
    cnaes: [
      { code: "4120400", description: "Construção de edifícios", role: "principal" },
      { code: "4399101", description: "Administração de obras", role: "relacionado" },
      { code: "4399199", description: "Serviços especializados para construção não especificados anteriormente", role: "relacionado" },
    ],
    keywords: ["construtora", "empreiteira", "incorporadora", "obras civis", "reformas"],
  },
  distribuidores: {
    id: "distribuidores",
    label: "Distribuidores e revendedores",
    defaultWeight: 0,
    channel: true,
    cnaes: [
      { code: "4679699", description: "Comércio atacadista de materiais de construção em geral", role: "principal" },
      { code: "4744099", description: "Comércio varejista de materiais de construção em geral", role: "principal" },
    ],
    keywords: ["distribuidora", "revenda", "materiais de construcao", "deposito de construcao", "atacado"],
  },
  outro: {
    id: "outro",
    label: "Outro (critérios livres)",
    defaultWeight: 0,
    channel: false,
    cnaes: [],
    keywords: [],
  },
};

export const SEGMENT_LABELS: Record<SegmentId, string> = Object.fromEntries(
  SEGMENT_IDS.map((id) => [id, SEGMENTS[id].label]),
) as Record<SegmentId, string>;

export function allCnaesFor(segment: SegmentId, extra: string[] = []): string[] {
  const set = new Set<string>([...SEGMENTS[segment].cnaes.map((c) => c.code), ...extra]);
  return [...set];
}
