import { onlyDigits, normalizeCompanyName, normalizePhone, stripAccentsLower, websiteHost } from "./normalize";
import { SEGMENTS } from "./segments";
import { safeFetchText, UnsafeUrlError, type SafeFetchOptions } from "./ssrf";
import { mergeLeads } from "./leads";
import type { Lead, SegmentId } from "./types";

const FREE_MAIL = new Set([
  "gmail.com", "hotmail.com", "outlook.com", "yahoo.com", "yahoo.com.br", "uol.com.br", "bol.com.br",
  "terra.com.br", "icloud.com", "live.com", "msn.com", "ig.com.br", "globo.com", "proton.me",
]);

/** Deduz um website candidato a partir do domínio do e-mail corporativo. Resultado: INFERIDO. */
export function inferWebsiteFromEmail(email: string | null | undefined): string | null {
  const domain = email?.split("@")[1]?.toLowerCase().trim();
  if (!domain || !domain.includes(".") || FREE_MAIL.has(domain)) return null;
  return `https://${domain.replace(/^www\./, "")}`;
}

/** Interpreta robots.txt de forma conservadora: vale o grupo do nosso agente ou "*". */
export function isAllowedByRobots(robots: string, agentToken: string, pathName: string): boolean {
  const lines = robots.split(/\r?\n/).map((l) => l.replace(/#.*$/, "").trim()).filter(Boolean);
  const groups: { agents: string[]; rules: { allow: boolean; path: string }[] }[] = [];
  let cur: (typeof groups)[number] | null = null;
  let lastWasAgent = false;
  for (const line of lines) {
    const idx = line.indexOf(":");
    if (idx < 0) continue;
    const key = line.slice(0, idx).trim().toLowerCase();
    const val = line.slice(idx + 1).trim();
    if (key === "user-agent") {
      if (!cur || !lastWasAgent) { cur = { agents: [], rules: [] }; groups.push(cur); }
      cur.agents.push(val.toLowerCase());
      lastWasAgent = true;
    } else if ((key === "allow" || key === "disallow") && cur) {
      cur.rules.push({ allow: key === "allow", path: val });
      lastWasAgent = false;
    } else lastWasAgent = false;
  }
  const token = agentToken.toLowerCase();
  const specific = groups.filter((g) => g.agents.some((a) => a !== "*" && token.includes(a)));
  const chosen = specific.length ? specific : groups.filter((g) => g.agents.includes("*"));
  let best: { allow: boolean; len: number } | null = null;
  for (const g of chosen) {
    for (const r of g.rules) {
      if (!r.path) continue; // "Disallow:" vazio = tudo permitido
      if (pathName.startsWith(r.path.replace(/\*$/, ""))) {
        if (!best || r.path.length > best.len || (r.path.length === best.len && r.allow)) best = { allow: r.allow, len: r.path.length };
      }
    }
  }
  return best ? best.allow : true;
}

export interface PageFacts {
  title: string;
  description: string;
  phones: string[];
  emails: string[];
  text: string;
}

export function extractFacts(html: string): PageFacts {
  const clean = html.replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>/gi, " ");
  const title = clean.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]?.replace(/\s+/g, " ").trim() ?? "";
  const description =
    clean.match(/<meta[^>]+name=["']description["'][^>]*content=["']([^"']*)["']/i)?.[1]?.trim() ??
    clean.match(/<meta[^>]+content=["']([^"']*)["'][^>]*name=["']description["']/i)?.[1]?.trim() ?? "";
  const phones = [...clean.matchAll(/href=["']tel:([^"']+)["']/gi)].map((m) => m[1] ?? "");
  const emails = [...clean.matchAll(/href=["']mailto:([^"'?]+)/gi)].map((m) => (m[1] ?? "").toLowerCase());
  const text = clean.replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim().slice(0, 20000);
  return { title, description, phones, emails, text };
}

/** O site é da empresa se mencionar o CNPJ ou o nome (fantasia/razão) normalizado. */
export function siteConfirmsCompany(facts: PageFacts, lead: Pick<Lead, "cnpj" | "razaoSocial" | "nomeFantasia">): boolean {
  const digits = onlyDigits(facts.text);
  if (lead.cnpj && digits.includes(lead.cnpj)) return true;
  const hay = normalizeCompanyName(`${facts.title} ${facts.text.slice(0, 4000)}`);
  const names = [lead.nomeFantasia, lead.razaoSocial].map((n) => normalizeCompanyName(n)).filter((n) => n.length >= 6);
  return names.some((n) => hay.includes(n));
}

export interface EnrichOptions extends Partial<SafeFetchOptions> {
  segment: SegmentId;
  extraKeywords?: string[];
}

export type EnrichOutcome = { lead: Lead; status: "enriquecido" | "ignorado"; reason?: string };

export async function enrichLead(lead: Lead, opts: EnrichOptions): Promise<EnrichOutcome> {
  if (!lead.website) return { lead, status: "ignorado", reason: "sem website" };
  const base: SafeFetchOptions = {
    timeoutMs: opts.timeoutMs ?? (Number(process.env.ENRICHMENT_TIMEOUT_MS) || 6000),
    maxBytes: opts.maxBytes ?? 300_000,
    userAgent: opts.userAgent ?? process.env.ENRICHMENT_USER_AGENT ?? "ProspectFinderBot/0.1",
    ...(opts.fetchImpl ? { fetchImpl: opts.fetchImpl } : {}),
    ...(opts.resolver ? { resolver: opts.resolver } : {}),
  };
  try {
    const host = websiteHost(lead.website);
    if (!host) return { lead, status: "ignorado", reason: "website inválido" };
    const origin = `https://${host}`;
    // robots.txt: 4xx = permitido; falha de rede/5xx = não coleta.
    let robots = "";
    try {
      const r = await safeFetchText(`${origin}/robots.txt`, base);
      if (r.status >= 500) return { lead, status: "ignorado", reason: "robots.txt indisponível" };
      if (r.status < 400) robots = r.text;
    } catch (e) {
      if (e instanceof UnsafeUrlError) throw e;
      return { lead, status: "ignorado", reason: "robots.txt inacessível" };
    }
    if (!isAllowedByRobots(robots, base.userAgent.split("/")[0] ?? "ProspectFinderBot", "/")) {
      return { lead, status: "ignorado", reason: "bloqueado por robots.txt" };
    }
    const page = await safeFetchText(`${origin}/`, base);
    if (page.status >= 400 || !/html|text/i.test(page.contentType)) return { lead, status: "ignorado", reason: `resposta ${page.status}` };
    const facts = extractFacts(page.text);
    const confirmed = siteConfirmsCompany(facts, lead);
    const now = new Date().toISOString();
    const kws = [...SEGMENTS[opts.segment].keywords, ...(opts.extraKeywords ?? [])].map(stripAccentsLower);
    const snippets = [facts.title, facts.description].filter(Boolean);
    const hits = kws.filter((k) => stripAccentsLower(snippets.join(" ") + " " + facts.text).includes(k));
    const evidence = hits.length ? [`${snippets.join(" — ").slice(0, 200)} [termos: ${hits.slice(0, 5).join(", ")}]`] : [];

    const incoming: Lead = {
      ...lead,
      phone: confirmed ? (facts.phones.map((p) => normalizePhone(p)?.formatted).find(Boolean) ?? null) : null,
      email: confirmed ? (facts.emails[0] ?? null) : null,
      provenance: {},
      sources: ["website"],
      siteEvidence: confirmed ? evidence : [],
      updatedAt: now,
    };
    const src = { source: "website" as const, updatedAt: now, url: page.finalUrl };
    if (incoming.phone) incoming.provenance["phone"] = { ...src, confidence: "verified" };
    if (incoming.email) incoming.provenance["email"] = { ...src, confidence: "verified" };
    const merged = mergeLeads(lead, incoming);
    if (confirmed) {
      merged.provenance["website"] = { ...src, confidence: "verified" };
      merged.sourceUrl = merged.sourceUrl ?? page.finalUrl;
    } else if (evidence.length) {
      merged.siteEvidence = [...new Set([...merged.siteEvidence, ...evidence])]; // não pontua sem confirmação
    }
    return { lead: merged, status: "enriquecido", reason: confirmed ? "site confirmado" : "site não confirmado como da empresa" };
  } catch (e) {
    return { lead, status: "ignorado", reason: e instanceof UnsafeUrlError ? `bloqueado: ${e.message}` : "falha ao consultar o site" };
  }
}
