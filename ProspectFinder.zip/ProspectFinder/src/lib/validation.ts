import { z } from "zod";
import { LEAD_STATUSES, SEGMENT_IDS, UFS } from "./types";
import { normalizeCnae, onlyDigits } from "./normalize";

export const MAX_LIMIT = Number(process.env.SEARCH_MAX_LIMIT ?? 500) || 500;

const cleanList = (max: number, itemMax: number) =>
  z
    .array(z.string().trim().min(1).max(itemMax))
    .max(max)
    .default([]);

export const SearchRequestSchema = z
  .object({
    mode: z.enum(["manual", "strategy"]).default("manual"),
    segment: z.enum(SEGMENT_IDS).default("impermeabilizacao"),
    split: z
      .object({
        impermeabilizacao: z.number().min(0).max(100),
        construcao_a_seco: z.number().min(0).max(100),
      })
      .default({ impermeabilizacao: 70, construcao_a_seco: 30 }),
    uf: z.union([z.enum(UFS), z.literal("BR")]),
    cities: cleanList(20, 80),
    keywords: cleanList(20, 80),
    cnaes: z
      .array(z.string())
      .max(20)
      .default([])
      .transform((arr) => arr.map((c) => normalizeCnae(c)))
      .refine((arr) => arr.every((c) => c !== null), { message: "CNAE inválido: use 7 dígitos (ex.: 4330-4/01)." })
      .transform((arr) => [...new Set(arr as string[])]),
    situacao: z.enum(["ativa", "todas"]).default("ativa"),
    estabelecimento: z.enum(["matriz", "todos"]).default("todos"),
    limit: z.number().int().min(1).max(MAX_LIMIT).default(50),
    sources: z.array(z.enum(["cnpj-local", "demo"])).min(1, "Habilite ao menos uma fonte.").max(3),
    enrich: z.boolean().default(false),
  })
  .superRefine((v, ctx) => {
    if (v.mode === "strategy" && v.split.impermeabilizacao + v.split.construcao_a_seco !== 100) {
      ctx.addIssue({ code: "custom", path: ["split"], message: "Os percentuais devem somar 100." });
    }
    if (v.uf === "BR" && v.cities.length > 0) {
      ctx.addIssue({ code: "custom", path: ["cities"], message: "Cidades só podem ser usadas com um estado específico." });
    }
    if (v.segment === "outro" && v.mode === "manual" && v.keywords.length === 0 && v.cnaes.length === 0) {
      ctx.addIssue({ code: "custom", path: ["keywords"], message: "Informe palavras-chave ou CNAEs para o segmento livre." });
    }
  });

export const LeadPatchSchema = z
  .object({
    status: z.enum(LEAD_STATUSES).optional(),
    notes: z.string().max(4000).optional(),
  })
  .strict()
  .refine((v) => v.status !== undefined || v.notes !== undefined, { message: "Nada para atualizar." });

export const LeadQuerySchema = z.object({
  q: z.string().trim().max(120).optional(),
  segment: z.enum(SEGMENT_IDS).optional(),
  uf: z.enum(UFS).optional(),
  city: z.string().trim().max(80).optional(),
  status: z.enum(LEAD_STATUSES).optional(),
  searchId: z.string().trim().max(64).optional(),
  sort: z
    .enum(["razaoSocial", "cnpj", "segment", "city", "uf", "score", "discoveredAt", "status"])
    .default("discoveredAt"),
  dir: z.enum(["asc", "desc"]).default("desc"),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(200).default(25),
});
export type LeadQuery = z.infer<typeof LeadQuerySchema>;

export function searchTerm(q: string | undefined): { text: string; digits: string } {
  return { text: (q ?? "").trim().toLowerCase(), digits: onlyDigits(q) };
}

export function flattenZodError(err: z.ZodError): string[] {
  return err.issues.map((i) => (i.path.length ? `${i.path.join(".")}: ${i.message}` : i.message));
}
