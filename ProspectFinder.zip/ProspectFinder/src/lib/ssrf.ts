import dns from "node:dns/promises";
import net from "node:net";

export class UnsafeUrlError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "UnsafeUrlError";
  }
}

export function isPrivateIp(ip: string): boolean {
  const v = net.isIP(ip);
  if (v === 4) {
    const [a = 0, b = 0] = ip.split(".").map(Number);
    return (
      a === 0 || a === 10 || a === 127 || a >= 224 ||
      (a === 100 && b >= 64 && b <= 127) ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) ||
      (a === 192 && b === 0) ||
      (a === 198 && (b === 18 || b === 19))
    );
  }
  if (v === 6) {
    const l = ip.toLowerCase();
    if (l === "::" || l === "::1") return true;
    const mapped = l.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
    if (mapped?.[1]) return isPrivateIp(mapped[1]);
    return /^f[cd]/.test(l) || /^fe[89ab]/.test(l) || l.startsWith("ff");
  }
  return true; // não é IP válido: trate como inseguro
}

export type Resolver = (hostname: string) => Promise<string[]>;

export const defaultResolver: Resolver = async (host) =>
  (await dns.lookup(host, { all: true })).map((r) => r.address);

/** Aceita apenas http(s) público, sem credenciais, portas 80/443 e host que resolva só para IPs públicos. */
export async function assertPublicUrl(raw: string, resolve: Resolver = defaultResolver): Promise<URL> {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    throw new UnsafeUrlError("URL inválida.");
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") throw new UnsafeUrlError("Protocolo não permitido.");
  if (url.username || url.password) throw new UnsafeUrlError("URL com credenciais não é permitida.");
  if (url.port && url.port !== "80" && url.port !== "443") throw new UnsafeUrlError("Porta não permitida.");
  const host = url.hostname.replace(/^\[|\]$/g, "");
  if (net.isIP(host)) {
    if (isPrivateIp(host)) throw new UnsafeUrlError("Endereço IP privado não é permitido.");
    return url;
  }
  if (host === "localhost" || host.endsWith(".local") || host.endsWith(".internal")) {
    throw new UnsafeUrlError("Host interno não é permitido.");
  }
  let addrs: string[];
  try {
    addrs = await resolve(host);
  } catch {
    throw new UnsafeUrlError("Não foi possível resolver o domínio.");
  }
  if (addrs.length === 0 || addrs.some(isPrivateIp)) throw new UnsafeUrlError("O domínio resolve para endereço não público.");
  return url;
}

export interface SafeFetchOptions {
  timeoutMs: number;
  maxBytes: number;
  userAgent: string;
  fetchImpl?: typeof fetch;
  resolver?: Resolver;
  maxRedirects?: number;
}

export interface SafeFetchResult {
  status: number;
  finalUrl: string;
  contentType: string;
  text: string;
}

/** fetch com validação anti-SSRF a cada salto de redirecionamento, limite de tamanho e timeout. */
export async function safeFetchText(rawUrl: string, opts: SafeFetchOptions): Promise<SafeFetchResult> {
  const f = opts.fetchImpl ?? fetch;
  let current = rawUrl;
  for (let hop = 0; hop <= (opts.maxRedirects ?? 3); hop++) {
    const url = await assertPublicUrl(current, opts.resolver);
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), opts.timeoutMs);
    try {
      const res = await f(url.toString(), {
        redirect: "manual",
        signal: ctrl.signal,
        headers: { "user-agent": opts.userAgent, accept: "text/html,text/plain;q=0.9,*/*;q=0.1" },
      });
      if (res.status >= 300 && res.status < 400) {
        const loc = res.headers.get("location");
        if (!loc) throw new UnsafeUrlError("Redirecionamento sem destino.");
        current = new URL(loc, url).toString();
        continue;
      }
      const contentType = res.headers.get("content-type") ?? "";
      let text = "";
      if (res.body) {
        const reader = res.body.getReader();
        const chunks: Uint8Array[] = [];
        let total = 0;
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          total += value.length;
          chunks.push(value);
          if (total >= opts.maxBytes) { await reader.cancel(); break; }
        }
        text = new TextDecoder("utf-8", { fatal: false }).decode(Buffer.concat(chunks).subarray(0, opts.maxBytes));
      }
      return { status: res.status, finalUrl: url.toString(), contentType, text };
    } finally {
      clearTimeout(timer);
    }
  }
  throw new UnsafeUrlError("Redirecionamentos demais.");
}
