import { Suspense } from "react";
import { LeadsView } from "./leads-view";

export default function LeadsPage() {
  return (
    <Suspense fallback={<p className="text-sm text-muted">Carregando…</p>}>
      <LeadsView />
    </Suspense>
  );
}
