"use client";
import { useSearchParams } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import { ArrowDown, ArrowUp, Download, ExternalLink, X } from "lucide-react";
import { Badge, Button, Field, Input, Notice, Select, Spinner, api } from "@/components/ui";
import { SEGMENT_LABELS } from "@/lib/segments";
import { formatCnae, formatCnpj } from "@/lib/normalize";
import { LEAD_STATUSES, SEGMENT_IDS, STATUS_LABELS, UFS, type Lead, type LeadStatus } from "@/lib/types";

interface PageData { items: Lead[]; page: number; pageSize: number; total: number; totalPages: number; persistence: { kind: string; persistent: boolean } }
type SortKey = "razaoSocial" | "cnpj" | "segment" | "city" | "uf" | "score" | "discoveredAt" | "status";

const COLS: { key: SortKey | null; label: string }[] = [
  { key: "razaoSocial", label: "Empresa" }, { key: "cnpj", label: "CNPJ" }, { key: "segment", label: "Segmento" },
  { key: "city", label: "Cidade" }, { key: "uf", label: "UF" }, { key: null, label: "Telefone" }, { key: null, label: "E-mail" },
  { key: null, label: "Website" }, { key: null, label: "CNAE" }, { key: "score", label: "Pontuação" }, { key: null, label: "Origem" },
  { key: "discoveredAt", label: "Descoberta" }, { key: "status", label: "Status" }, { key: null, label: "Observações" },
];

const Missing = () => <span className="text-muted/60" title="Dado ausente">—</span>;

export function LeadsView() {
  const params = useSearchParams();
  const searchId = params.get("searchId") ?? "";
  const [q, setQ] = useState("");
  const [segment, setSegment] = useState("");
  const [uf, setUf] = useState("");
  const [city, setCity] = useState("");
  const [status, setStatus] = useState("");
  const [sort, setSort] = useState<SortKey>("discoveredAt");
  const [dir, setDir] = useState<"asc" | "desc">("desc");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  const [data, setData] = useState<PageData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [detail, setDetail] = useState<Lead | null>(null);

  const qs = useCallback(() => {
    const p = new URLSearchParams();
    const set = (k: string, v: string) => v && p.set(k, v);
    set("q", q); set("segment", segment); set("uf", uf); set("city", city); set("status", status); set("searchId", searchId);
    p.set("sort", sort); p.set("dir", dir);
    return p;
  }, [q, segment, uf, city, status, searchId, sort, dir]);

  useEffect(() => {
    const t = setTimeout(async () => {
      setLoading(true);
      setError(null);
      try {
        const p = qs();
        p.set("page", String(page)); p.set("pageSize", String(pageSize));
        setData(await api<PageData>(`/api/leads?${p}`));
      } catch (e) { setError((e as Error).message); } finally { setLoading(false); }
    }, 250);
    return () => clearTimeout(t);
  }, [qs, page, pageSize]);

  useEffect(() => setPage(1), [q, segment, uf, city, status, sort, dir, pageSize]);

  const toggleSort = (k: SortKey) => { if (k === sort) setDir(dir === "asc" ? "desc" : "asc"); else { setSort(k); setDir("asc"); } };
  const toggle = (id: string) => setSelected((s) => { const n = new Set(s); if (n.has(id)) n.delete(id); else n.add(id); return n; });
  const allOnPage = !!data?.items.length && data.items.every((l) => selected.has(l.id));

  function exportCsv() {
    const p = qs();
    if (selected.size) p.set("ids", [...selected].join(","));
    window.location.href = `/api/leads/export?${p}`;
  }

  function onSaved(lead: Lead) {
    setDetail(lead);
    setData((d) => (d ? { ...d, items: d.items.map((x) => (x.id === lead.id ? lead : x)) } : d));
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h1 className="text-xl font-semibold">Leads</h1>
        <Button variant="secondary" onClick={exportCsv} disabled={!data?.total}>
          <Download size={15} aria-hidden /> Exportar CSV{selected.size ? ` (${selected.size} selecionados)` : ""}
        </Button>
      </div>

      {data && !data.persistence.persistent && (
        <Notice tone="warn" title="Dados somente em memória">Google Sheets não está configurado; estes leads somem ao reiniciar o servidor.</Notice>
      )}
      {searchId && <Notice tone="info">Mostrando leads da pesquisa selecionada. <a className="underline" href="/leads">Ver todos</a></Notice>}

      <div className="grid gap-2 rounded-lg border border-line bg-surface p-3 sm:grid-cols-2 lg:grid-cols-5">
        <Input aria-label="Buscar por nome ou CNPJ" placeholder="Buscar por nome ou CNPJ" value={q} onChange={(e) => setQ(e.target.value)} />
        <Select aria-label="Segmento" value={segment} onChange={(e) => setSegment(e.target.value)}>
          <option value="">Todos os segmentos</option>
          {SEGMENT_IDS.map((s) => <option key={s} value={s}>{SEGMENT_LABELS[s]}</option>)}
        </Select>
        <Select aria-label="Estado" value={uf} onChange={(e) => setUf(e.target.value)}>
          <option value="">Todos os estados</option>
          {UFS.map((u) => <option key={u}>{u}</option>)}
        </Select>
        <Input aria-label="Cidade" placeholder="Cidade" value={city} onChange={(e) => setCity(e.target.value)} />
        <Select aria-label="Status" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">Todos os status</option>
          {LEAD_STATUSES.map((s) => <option key={s} value={s}>{STATUS_LABELS[s]}</option>)}
        </Select>
      </div>

      {error && <Notice tone="bad" title="Não foi possível carregar os leads">{error}</Notice>}

      <div className="overflow-x-auto rounded-lg border border-line bg-surface">
        <table className="w-full min-w-[1400px] text-left text-sm">
          <thead className="border-b border-line bg-paper text-xs text-muted">
            <tr>
              <th className="w-10 px-3 py-2"><input type="checkbox" aria-label="Selecionar todos da página" checked={allOnPage}
                onChange={() => setSelected((s) => { const n = new Set(s); data?.items.forEach((l) => (allOnPage ? n.delete(l.id) : n.add(l.id))); return n; })} /></th>
              {COLS.map((c) => (
                <th key={c.label} className="px-3 py-2 font-medium" aria-sort={c.key && c.key === sort ? (dir === "asc" ? "ascending" : "descending") : undefined}>
                  {c.key ? (
                    <button onClick={() => toggleSort(c.key!)} className="inline-flex items-center gap-1 hover:text-ink">
                      {c.label}{c.key === sort && (dir === "asc" ? <ArrowUp size={12} /> : <ArrowDown size={12} />)}
                    </button>
                  ) : c.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {loading && !data && <tr><td colSpan={COLS.length + 1} className="px-3 py-8 text-center text-muted"><Spinner /> Carregando…</td></tr>}
            {data && data.items.length === 0 && (
              <tr><td colSpan={COLS.length + 1} className="px-3 py-10 text-center text-muted">
                Nenhum lead encontrado. Ajuste os filtros ou <a className="text-accent underline" href="/pesquisa">faça uma pesquisa</a>.
              </td></tr>
            )}
            {data?.items.map((l) => (
              <tr key={l.id} className="cursor-pointer border-b border-line/70 last:border-0 hover:bg-paper/60" onClick={() => setDetail(l)}>
                <td className="px-3 py-2" onClick={(e) => e.stopPropagation()}>
                  <input type="checkbox" aria-label={`Selecionar ${l.razaoSocial}`} checked={selected.has(l.id)} onChange={() => toggle(l.id)} />
                </td>
                <td className="px-3 py-2 font-medium">
                  <button className="text-left hover:underline" onClick={(e) => { e.stopPropagation(); setDetail(l); }}>{l.nomeFantasia ?? l.razaoSocial}</button>
                  {l.isDemo && <> <Badge tone="warn">fictício</Badge></>}
                </td>
                <td className="px-3 py-2 tabular-nums">{l.cnpj ? formatCnpj(l.cnpj) : <Missing />}</td>
                <td className="px-3 py-2">{SEGMENT_LABELS[l.segment]}</td>
                <td className="px-3 py-2">{l.city ?? <Missing />}</td>
                <td className="px-3 py-2">{l.uf ?? <Missing />}</td>
                <td className="px-3 py-2 tabular-nums">{l.phone ?? <Missing />}</td>
                <td className="px-3 py-2">{l.email ?? <Missing />}</td>
                <td className="px-3 py-2">{l.website ? <>{l.website.replace(/^https?:\/\//, "")}{l.provenance["website"]?.confidence === "inferred" && <> <Badge>inferido</Badge></>}</> : <Missing />}</td>
                <td className="px-3 py-2 tabular-nums">{l.cnaePrincipal ? formatCnae(l.cnaePrincipal) : <Missing />}</td>
                <td className="px-3 py-2 font-medium tabular-nums">{l.score}</td>
                <td className="px-3 py-2 text-muted">{l.sources.join(", ")}</td>
                <td className="px-3 py-2 tabular-nums">{l.discoveredAt.slice(0, 10)}</td>
                <td className="px-3 py-2">{STATUS_LABELS[l.status]}</td>
                <td className="max-w-48 truncate px-3 py-2 text-muted">{l.notes || <Missing />}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {data && (
        <div className="flex flex-wrap items-center justify-between gap-3 text-sm">
          <p className="text-muted">{data.total} lead(s) · página {data.page} de {data.totalPages}</p>
          <div className="flex items-center gap-2">
            <Select aria-label="Itens por página" className="w-auto" value={pageSize} onChange={(e) => setPageSize(Number(e.target.value))}>
              {[10, 25, 50, 100].map((n) => <option key={n} value={n}>{n} por página</option>)}
            </Select>
            <Button variant="secondary" disabled={data.page <= 1} onClick={() => setPage(data.page - 1)}>Anterior</Button>
            <Button variant="secondary" disabled={data.page >= data.totalPages} onClick={() => setPage(data.page + 1)}>Próxima</Button>
          </div>
        </div>
      )}

      {detail && <Detail lead={detail} onClose={() => setDetail(null)} onSaved={onSaved} />}
    </div>
  );
}

function Detail({ lead, onClose, onSaved }: { lead: Lead; onClose: () => void; onSaved: (l: Lead) => void }) {
  const [status, setStatus] = useState<LeadStatus>(lead.status);
  const [notes, setNotes] = useState(lead.notes);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ tone: "ok" | "warn" | "bad"; text: string } | null>(null);
  useEffect(() => { setStatus(lead.status); setNotes(lead.notes); setMsg(null); }, [lead.id, lead.status, lead.notes]);
  const dirty = status !== lead.status || notes !== lead.notes;

  async function save() {
    setBusy(true); setMsg(null);
    try {
      const r = await api<{ lead: Lead; persisted: boolean }>(`/api/leads/${lead.id}`, { method: "PATCH", body: JSON.stringify({ status, notes }) });
      onSaved(r.lead);
      setMsg(r.persisted ? { tone: "ok", text: "Alterações salvas no Google Sheets." } : { tone: "warn", text: "Salvo somente em memória (Google Sheets não configurado)." });
    } catch (e) { setMsg({ tone: "bad", text: (e as Error).message }); } finally { setBusy(false); }
  }

  const row = (k: string, v: React.ReactNode) => (
    <div className="grid grid-cols-[110px_1fr] gap-2 py-1.5 text-sm"><dt className="text-muted">{k}</dt><dd className="break-words">{v ?? <Missing />}</dd></div>
  );
  const prov = (f: string) => {
    const p = lead.provenance[f];
    return p ? <span className="ml-1 text-xs text-muted">({p.source}, {p.confidence === "verified" ? "verificado" : "inferido"})</span> : null;
  };

  return (
    <div className="fixed inset-0 z-20 flex justify-end bg-black/30" onClick={onClose}>
      <aside role="dialog" aria-modal="true" aria-label="Detalhes do lead" className="h-full w-full max-w-lg overflow-y-auto bg-surface p-5 shadow-xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between gap-3">
          <div>
            <h2 className="text-lg font-semibold">{lead.nomeFantasia ?? lead.razaoSocial}</h2>
            {lead.nomeFantasia && <p className="text-sm text-muted">{lead.razaoSocial}</p>}
            {lead.isDemo && <Badge tone="warn">Dado fictício de demonstração</Badge>}
          </div>
          <button aria-label="Fechar" onClick={onClose} className="grid h-8 w-8 place-items-center rounded hover:bg-paper"><X size={18} /></button>
        </div>

        <dl className="mt-4 divide-y divide-line/60">
          {row("CNPJ", lead.cnpj ? <>{formatCnpj(lead.cnpj)}{prov("cnpj")}</> : null)}
          {row("Segmento", SEGMENT_LABELS[lead.segment])}
          {row("Local", [lead.city, lead.uf].filter(Boolean).join(" / ") || null)}
          {row("Situação", lead.situacaoCadastral)}
          {row("Telefone", lead.phone ? <>{lead.phone}{prov("phone")}</> : null)}
          {row("E-mail", lead.email ? <>{lead.email}{prov("email")}</> : null)}
          {row("Website", lead.website ? <>{lead.website}{prov("website")}</> : null)}
          {row("CNAE principal", lead.cnaePrincipal ? <>{formatCnae(lead.cnaePrincipal)}{prov("cnae")}</> : null)}
          {row("CNAEs sec.", lead.cnaesSecundarios.length ? lead.cnaesSecundarios.slice(0, 12).map(formatCnae).join(", ") : null)}
          {row("Descoberta", lead.discoveredAt.slice(0, 10))}
          {row("Fonte original", lead.sourceUrl ? <a className="inline-flex items-center gap-1 text-accent underline" href={lead.sourceUrl} target="_blank" rel="noopener noreferrer">Abrir fonte <ExternalLink size={12} /></a> : null)}
        </dl>

        <section className="mt-5">
          <h3 className="text-sm font-semibold">Pontuação de aderência: {lead.score}/100</h3>
          <ul className="mt-2 space-y-1.5 text-sm">
            {lead.scoreBreakdown.map((c) => (
              <li key={c.id} className="flex gap-2">
                <Badge tone={c.status === "met" ? "ok" : c.status === "unknown" ? "neutral" : "bad"}>{c.status === "met" ? `+${c.points}` : c.status === "unknown" ? "desconhecido" : "0"}</Badge>
                <span><span className="font-medium">{c.label}.</span> <span className="text-muted">{c.detail}</span></span>
              </li>
            ))}
          </ul>
        </section>

        <section className="mt-5 space-y-3">
          <h3 className="text-sm font-semibold">Acompanhamento comercial</h3>
          <Field label="Status" htmlFor="d-status">
            <Select id="d-status" value={status} onChange={(e) => setStatus(e.target.value as LeadStatus)}>
              {LEAD_STATUSES.map((s) => <option key={s} value={s}>{STATUS_LABELS[s]}</option>)}
            </Select>
          </Field>
          <Field label="Observações" htmlFor="d-notes">
            <textarea id="d-notes" rows={4} maxLength={4000} value={notes} onChange={(e) => setNotes(e.target.value)} className="w-full rounded-md border border-line bg-surface p-2.5 text-sm" />
          </Field>
          {msg && <Notice tone={msg.tone}>{msg.text}</Notice>}
          <Button onClick={save} disabled={!dirty || busy}>{busy && <Spinner />} Salvar alterações</Button>
        </section>
      </aside>
    </div>
  );
}
