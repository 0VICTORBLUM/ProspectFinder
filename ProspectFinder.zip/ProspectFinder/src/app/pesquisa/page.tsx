"use client";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { Badge, Button, Field, Input, Notice, Select, Spinner, api } from "@/components/ui";
import { SEGMENT_LABELS } from "@/lib/segments";
import { SEGMENT_IDS, UFS, type SearchResult, type SegmentId, type SourceAvailability, type SourceId } from "@/lib/types";

interface Config {
  persistence: { kind: string; persistent: boolean };
  sources: { id: SourceId; label: string; description: string; demo: boolean; availability: SourceAvailability }[];
  cnaeCatalogValidated: boolean;
  maxLimit: number;
}
type View = SearchResult & { distribution?: { segment: string; target: number; achieved: number; targetPct: number; achievedPct: number; met: boolean }[] };

const STATUS_TEXT: Record<string, string> = {
  pendente: "Pendente", em_andamento: "Em andamento", concluida: "Concluída", parcial: "Parcial (com erro)", erro: "Erro", cancelada: "Cancelada",
};
const TERMINAL = ["concluida", "parcial", "erro", "cancelada"];
const list = (s: string) => s.split(/[,\n;]/).map((x) => x.trim()).filter(Boolean);

export default function PesquisaPage() {
  const [config, setConfig] = useState<Config | null>(null);
  const [configError, setConfigError] = useState<string | null>(null);
  const [mode, setMode] = useState<"manual" | "strategy">("strategy");
  const [segment, setSegment] = useState<SegmentId>("impermeabilizacao");
  const [pctImp, setPctImp] = useState(70);
  const [uf, setUf] = useState<string>("PR");
  const [cities, setCities] = useState("");
  const [keywords, setKeywords] = useState("");
  const [cnaes, setCnaes] = useState("");
  const [situacao, setSituacao] = useState<"ativa" | "todas">("ativa");
  const [estab, setEstab] = useState<"matriz" | "todos">("todos");
  const [limit, setLimit] = useState(50);
  const [sources, setSources] = useState<SourceId[]>(["cnpj-local"]);
  const [enrich, setEnrich] = useState(false);

  const [search, setSearch] = useState<View | null>(null);
  const [running, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const cancelled = useRef(false);

  useEffect(() => {
    api<Config>("/api/config").then(setConfig).catch((e) => setConfigError((e as Error).message));
  }, []);

  const toggleSource = (id: SourceId) => setSources((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));

  async function start(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSearch(null);
    cancelled.current = false;
    setRunning(true);
    try {
      const body = {
        mode, segment,
        split: { impermeabilizacao: pctImp, construcao_a_seco: 100 - pctImp },
        uf, cities: uf === "BR" ? [] : list(cities), keywords: list(keywords), cnaes: list(cnaes),
        situacao, estabelecimento: estab, limit, sources, enrich,
      };
      let s = await api<View>("/api/searches", { method: "POST", body: JSON.stringify(body) });
      setSearch(s);
      while (!TERMINAL.includes(s.status) && !cancelled.current) {
        s = await api<View>(`/api/searches/${s.id}/step`, { method: "POST" });
        setSearch(s);
      }
      if (s.id) setSearch(await api<View>(`/api/searches/${s.id}`));
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setRunning(false);
    }
  }

  async function cancel() {
    cancelled.current = true;
    if (search) {
      try { setSearch(await api<View>(`/api/searches/${search.id}/cancel`, { method: "POST" })); } catch (e) { setError((e as Error).message); }
    }
  }

  const demoSelected = sources.includes("demo");

  return (
    <div className="mx-auto max-w-5xl space-y-5">
      <h1 className="text-xl font-semibold">Pesquisa</h1>

      {configError && <Notice tone="bad" title="Não foi possível carregar a configuração">{configError}</Notice>}
      {config && !config.persistence.persistent && (
        <Notice tone="warn" title="Google Sheets não configurado">
          Os leads desta sessão ficam só em memória e serão perdidos ao reiniciar o servidor. Veja a seção de configuração no README.
        </Notice>
      )}
      {config && !config.cnaeCatalogValidated && (
        <Notice tone="info" title="CNAEs ainda não validados">
          Os códigos do catálogo são pontos de partida. Confira-os na tabela oficial do IBGE/CONCLA antes de tratá-los como critério definitivo.
        </Notice>
      )}

      <form onSubmit={start} className="space-y-6 rounded-lg border border-line bg-surface p-5">
        <fieldset className="space-y-3">
          <legend className="text-sm font-semibold">Segmento</legend>
          <div className="flex flex-wrap gap-4 text-sm">
            <label className="flex items-center gap-2"><input type="radio" name="mode" checked={mode === "strategy"} onChange={() => setMode("strategy")} /> Orientada por estratégia (70/30)</label>
            <label className="flex items-center gap-2"><input type="radio" name="mode" checked={mode === "manual"} onChange={() => setMode("manual")} /> Manual</label>
          </div>
          {mode === "manual" ? (
            <Field label="Segmento da pesquisa" htmlFor="segment">
              <Select id="segment" value={segment} onChange={(e) => setSegment(e.target.value as SegmentId)}>
                {SEGMENT_IDS.map((s) => <option key={s} value={s}>{SEGMENT_LABELS[s]}</option>)}
              </Select>
            </Field>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Impermeabilização (%)" htmlFor="pctImp" hint="Meta de priorização, não uma restrição.">
                <Input id="pctImp" type="number" min={0} max={100} value={pctImp} onChange={(e) => setPctImp(Math.min(100, Math.max(0, Number(e.target.value) || 0)))} />
              </Field>
              <Field label="Construção a seco (%)" hint="Calculado: 100 menos o valor ao lado.">
                <Input value={100 - pctImp} readOnly aria-readonly />
              </Field>
            </div>
          )}
        </fieldset>

        <fieldset className="space-y-3">
          <legend className="text-sm font-semibold">Localização</legend>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Estado" htmlFor="uf">
              <Select id="uf" value={uf} onChange={(e) => setUf(e.target.value)}>
                <option value="BR">Todo o Brasil</option>
                {UFS.map((u) => <option key={u} value={u}>{u}</option>)}
              </Select>
            </Field>
            <Field label="Cidades (opcional)" htmlFor="cities" hint="Separe várias cidades por vírgula.">
              <Input id="cities" value={cities} disabled={uf === "BR"} onChange={(e) => setCities(e.target.value)} placeholder="Curitiba, Londrina" />
            </Field>
          </div>
        </fieldset>

        <fieldset className="space-y-3">
          <legend className="text-sm font-semibold">Critérios</legend>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Palavras-chave extras" htmlFor="kw" hint="Somadas às do segmento. Buscadas no nome da empresa.">
              <Input id="kw" value={keywords} onChange={(e) => setKeywords(e.target.value)} placeholder="manta líquida, poliuretano" />
            </Field>
            <Field label="CNAEs extras" htmlFor="cnaes" hint="7 dígitos, ex.: 4330-4/01.">
              <Input id="cnaes" value={cnaes} onChange={(e) => setCnaes(e.target.value)} placeholder="4330-4/01" />
            </Field>
            <Field label="Situação cadastral" htmlFor="sit">
              <Select id="sit" value={situacao} onChange={(e) => setSituacao(e.target.value as "ativa" | "todas")}>
                <option value="ativa">Somente ativas</option><option value="todas">Todas</option>
              </Select>
            </Field>
            <Field label="Tipo de empresa" htmlFor="estab">
              <Select id="estab" value={estab} onChange={(e) => setEstab(e.target.value as "matriz" | "todos")}>
                <option value="todos">Matrizes e filiais</option><option value="matriz">Somente matrizes</option>
              </Select>
            </Field>
            <Field label="Limite de resultados" htmlFor="limit" hint={config ? `Máximo ${config.maxLimit}.` : undefined}>
              <Input id="limit" type="number" min={1} max={config?.maxLimit ?? 500} value={limit} onChange={(e) => setLimit(Number(e.target.value) || 1)} />
            </Field>
          </div>
        </fieldset>

        <fieldset className="space-y-2">
          <legend className="text-sm font-semibold">Fontes de dados</legend>
          {config?.sources.filter((s) => s.id !== "website").map((s) => (
            <label key={s.id} className="flex items-start gap-2 text-sm">
              <input type="checkbox" className="mt-1" checked={sources.includes(s.id)} onChange={() => toggleSource(s.id)} />
              <span>
                {s.label}{" "}
                {s.availability.state === "available" ? <Badge tone="ok">disponível</Badge> : <Badge tone="warn">indisponível</Badge>}
                {s.demo && <Badge tone="warn">fictício</Badge>}
                <span className="block text-xs text-muted">{s.availability.state === "unavailable" ? s.availability.reason : s.description}</span>
              </span>
            </label>
          ))}
          <label className="flex items-start gap-2 text-sm">
            <input type="checkbox" className="mt-1" checked={enrich} onChange={(e) => setEnrich(e.target.checked)} />
            <span>Enriquecer com sites oficiais (opcional)
              <span className="block text-xs text-muted">Consulta o site da empresa respeitando robots.txt. Sites deduzidos do e-mail só pontuam depois de confirmados.</span>
            </span>
          </label>
        </fieldset>

        {demoSelected && <Notice tone="warn" title="Dados de demonstração">Esta pesquisa vai gerar empresas fictícias, identificadas como tal. Não use como leads reais.</Notice>}
        {error && <Notice tone="bad" title="Não foi possível concluir">{error}</Notice>}

        <div className="flex gap-2">
          <Button type="submit" disabled={running || sources.length === 0}>{running && <Spinner />} Iniciar pesquisa</Button>
          {running && <Button type="button" variant="secondary" onClick={cancel}>Cancelar pesquisa</Button>}
        </div>
      </form>

      {search && <Progress s={search} running={running} />}
    </div>
  );
}

function Progress({ s, running }: { s: View; running: boolean }) {
  const total = s.tasks.reduce((a, t) => a + t.target, 0);
  const pct = total ? Math.min(100, Math.round((s.counts.saved / total) * 100)) : 0;
  const finished = TERMINAL.includes(s.status);
  return (
    <section aria-live="polite" className="space-y-3 rounded-lg border border-line bg-surface p-5">
      <div className="flex flex-wrap items-center gap-2">
        <h2 className="text-base font-semibold">Resultado</h2>
        <Badge tone={s.status === "concluida" ? "ok" : s.status === "erro" || s.status === "parcial" ? "bad" : "neutral"}>{STATUS_TEXT[s.status]}</Badge>
        {s.dataMode === "demonstracao" && <Badge tone="warn">Somente dados fictícios</Badge>}
        {s.dataMode === "misto" && <Badge tone="warn">Inclui dados fictícios</Badge>}
        {s.dataMode === "real" && <Badge tone="ok">Dados reais</Badge>}
        {running && <Spinner />}
      </div>
      <div className="h-2 overflow-hidden rounded bg-paper" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
        <div className="h-full bg-accent transition-[width]" style={{ width: `${pct}%` }} />
      </div>
      <dl className="grid grid-cols-2 gap-3 text-sm sm:grid-cols-5">
        {[["Verificadas", s.counts.scanned], ["Encontradas", s.counts.found], ["Novas salvas", s.counts.saved], ["Duplicadas", s.counts.duplicates], ["Descartadas", s.counts.discarded]].map(([k, v]) => (
          <div key={k as string}><dt className="text-muted">{k}</dt><dd className="text-lg font-semibold">{v}</dd></div>
        ))}
      </dl>
      {s.tasks.length > 0 && (
        <ul className="space-y-1 text-sm">
          {s.tasks.map((t) => (
            <li key={t.segment}>{SEGMENT_LABELS[t.segment]}: {t.saved} de {t.target} {t.saved >= t.target ? "(meta atingida)" : t.done ? "(meta não atingida)" : ""}</li>
          ))}
        </ul>
      )}
      {finished && s.request.mode === "strategy" && s.distribution && (
        <p className="text-sm text-muted">
          Distribuição obtida: {s.distribution.map((d) => `${SEGMENT_LABELS[d.segment as SegmentId]} ${d.achievedPct}% (meta ${d.targetPct}%)`).join(" · ")}.
          {s.distribution.every((d) => d.met) ? "" : " A proporção planejada não foi cumprida porque não havia empresas suficientes."}
        </p>
      )}
      {Object.entries(s.discardReasons).length > 0 && (
        <p className="text-sm text-muted">Motivos de descarte: {Object.entries(s.discardReasons).map(([k, v]) => `${k.replace("_", " ")} (${v})`).join(", ")}.</p>
      )}
      {s.warnings.map((w, i) => <Notice key={i} tone="warn">{w}</Notice>)}
      {s.errors.map((w, i) => <Notice key={i} tone="bad">{w}</Notice>)}
      {s.status === "concluida" && s.persistence === "memoria" && s.counts.saved > 0 && (
        <Notice tone="warn" title="Não persistido">Os leads estão somente em memória; não foram gravados no Google Sheets.</Notice>
      )}
      {s.status === "concluida" && s.counts.saved === 0 && <Notice tone="info">Nenhuma empresa nova encontrada com esses critérios.</Notice>}
      {finished && s.counts.saved + s.counts.duplicates > 0 && (
        <Link href={`/leads?searchId=${s.id}`} className="inline-block text-sm font-medium text-accent underline">Ver leads desta pesquisa</Link>
      )}
    </section>
  );
}
