"use client";
import { useState } from "react";
import { Button, Field, Input, Notice, api } from "@/components/ui";

export default function LoginPage() {
  const [token, setToken] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api("/api/auth", { method: "POST", body: JSON.stringify({ token }) });
      window.location.href = "/pesquisa";
    } catch (err) {
      setError((err as Error).message);
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto mt-24 w-full max-w-sm space-y-4 px-4">
      <h1 className="text-xl font-semibold">Prospect Finder</h1>
      <form onSubmit={submit} className="space-y-3">
        <Field label="Token de acesso" htmlFor="token" hint="Definido na variável APP_ACCESS_TOKEN.">
          <Input id="token" type="password" autoComplete="current-password" value={token} onChange={(e) => setToken(e.target.value)} required />
        </Field>
        {error && <Notice tone="bad">{error}</Notice>}
        <Button type="submit" disabled={busy || !token} className="w-full">Entrar</Button>
      </form>
    </div>
  );
}
