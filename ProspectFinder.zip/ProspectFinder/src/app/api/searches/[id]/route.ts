import { NextResponse } from "next/server";
import { guard, ID_PATTERN, jsonError } from "@/lib/api";
import { distributionReport } from "@/lib/distribution";
import { getStore } from "@/lib/store";

export async function GET(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const denied = await guard(req);
  if (denied) return denied;
  const { id } = await ctx.params;
  if (!ID_PATTERN.test(id)) return jsonError(400, "Identificador inválido.");
  try {
    const search = await getStore().getSearch(id);
    if (!search) return jsonError(404, "Pesquisa não encontrada.");
    const targets = Object.fromEntries(search.tasks.map((t) => [t.segment, t.target]));
    const achieved = Object.fromEntries(search.tasks.map((t) => [t.segment, t.saved]));
    return NextResponse.json({ ...search, distribution: distributionReport(targets, achieved) });
  } catch (e) {
    console.error("[searches:get]", e);
    return jsonError(502, "Falha ao consultar a pesquisa.");
  }
}
