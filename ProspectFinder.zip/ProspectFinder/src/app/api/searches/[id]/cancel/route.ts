import { NextResponse } from "next/server";
import { guard, ID_PATTERN, jsonError } from "@/lib/api";
import { cancelSearch } from "@/lib/search";
import { getStore } from "@/lib/store";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const denied = await guard(req);
  if (denied) return denied;
  const { id } = await ctx.params;
  if (!ID_PATTERN.test(id)) return jsonError(400, "Identificador inválido.");
  try {
    const search = await cancelSearch(id, { store: getStore() });
    return search ? NextResponse.json(search) : jsonError(404, "Pesquisa não encontrada.");
  } catch (e) {
    console.error("[searches:cancel]", e);
    return jsonError(502, "Falha ao cancelar a pesquisa.");
  }
}
