import { NextResponse } from "next/server";
import { guard, ID_PATTERN, jsonError } from "@/lib/api";
import { stepSearch } from "@/lib/search";
import { getStore } from "@/lib/store";

export const maxDuration = 30;
export const dynamic = "force-dynamic";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const denied = await guard(req, { max: 600, bucket: "search-step" });
  if (denied) return denied;
  const { id } = await ctx.params;
  if (!ID_PATTERN.test(id)) return jsonError(400, "Identificador inválido.");
  try {
    const search = await stepSearch(id, { store: getStore() });
    if (!search) return jsonError(404, "Pesquisa não encontrada.");
    return NextResponse.json(search);
  } catch (e) {
    console.error("[searches:step]", e);
    return jsonError(502, "Falha ao executar o lote da pesquisa.");
  }
}
