import { NextResponse } from "next/server";
import { guard, jsonError, readJson } from "@/lib/api";
import { createSearch } from "@/lib/search";
import { getStore } from "@/lib/store";
import { flattenZodError, SearchRequestSchema } from "@/lib/validation";

export async function POST(req: Request) {
  const denied = await guard(req, { max: 30, bucket: "search-create" });
  if (denied) return denied;
  const body = await readJson(req);
  if (!body.ok) return body.res;
  const parsed = SearchRequestSchema.safeParse(body.data);
  if (!parsed.success) return jsonError(400, "Parâmetros de pesquisa inválidos.", flattenZodError(parsed.error));
  try {
    const search = await createSearch(parsed.data, { store: getStore() });
    return NextResponse.json(search, { status: 201 });
  } catch (e) {
    console.error("[searches:create]", e);
    return jsonError(502, "Não foi possível iniciar a pesquisa. Verifique a configuração do armazenamento.");
  }
}
