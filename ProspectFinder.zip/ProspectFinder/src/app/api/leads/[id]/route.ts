import { NextResponse } from "next/server";
import { guard, ID_PATTERN, jsonError, readJson } from "@/lib/api";
import { getStore } from "@/lib/store";
import { flattenZodError, LeadPatchSchema } from "@/lib/validation";

export async function GET(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const denied = await guard(req);
  if (denied) return denied;
  const { id } = await ctx.params;
  if (!ID_PATTERN.test(id)) return jsonError(400, "Identificador inválido.");
  try {
    const lead = await getStore().getLead(id);
    return lead ? NextResponse.json(lead) : jsonError(404, "Lead não encontrado.");
  } catch (e) {
    console.error("[leads:get]", e);
    return jsonError(502, "Falha ao ler o lead.");
  }
}

/** Somente campos comerciais (status e observações) podem ser alterados. */
export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const denied = await guard(req, { max: 120, bucket: "lead-patch" });
  if (denied) return denied;
  const { id } = await ctx.params;
  if (!ID_PATTERN.test(id)) return jsonError(400, "Identificador inválido.");
  const body = await readJson(req);
  if (!body.ok) return body.res;
  const parsed = LeadPatchSchema.safeParse(body.data);
  if (!parsed.success) return jsonError(400, "Campos inválidos.", flattenZodError(parsed.error));
  try {
    const store = getStore();
    const lead = await store.getLead(id);
    if (!lead) return jsonError(404, "Lead não encontrado.");
    const updated = { ...lead, ...parsed.data, updatedAt: new Date().toISOString() };
    await store.upsertLeads([updated]);
    return NextResponse.json({ lead: updated, persisted: store.persistent });
  } catch (e) {
    console.error("[leads:patch]", e);
    return jsonError(502, "Não foi possível salvar a alteração.");
  }
}
