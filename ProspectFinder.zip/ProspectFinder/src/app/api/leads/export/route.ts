import { guard, ID_PATTERN, jsonError } from "@/lib/api";
import { toCsv } from "@/lib/csv";
import { EXPORT_HEADERS, filterLeads, leadToExportRow, sortLeads } from "@/lib/lead-query";
import { getStore } from "@/lib/store";
import { flattenZodError, LeadQuerySchema } from "@/lib/validation";

export const dynamic = "force-dynamic";
const MAX_ROWS = 5000;

export async function GET(req: Request) {
  const denied = await guard(req, { max: 30, bucket: "export" });
  if (denied) return denied;
  const sp = new URL(req.url).searchParams;
  const params = Object.fromEntries(sp.entries());
  for (const k of Object.keys(params)) if (params[k] === "") delete params[k];
  const parsed = LeadQuerySchema.safeParse(params);
  if (!parsed.success) return jsonError(400, "Filtros inválidos.", flattenZodError(parsed.error));
  const ids = (sp.get("ids") ?? "").split(",").map((s) => s.trim()).filter(Boolean);
  if (ids.length > MAX_ROWS || ids.some((i) => !ID_PATTERN.test(i))) return jsonError(400, "Lista de ids inválida.");
  try {
    let leads = await getStore().listLeads();
    if (ids.length) leads = leads.filter((l) => ids.includes(l.id));
    leads = sortLeads(filterLeads(leads, parsed.data), parsed.data.sort, parsed.data.dir).slice(0, MAX_ROWS);
    const csv = toCsv(EXPORT_HEADERS, leads.map(leadToExportRow));
    return new Response(csv, {
      headers: {
        "content-type": "text/csv; charset=utf-8",
        "content-disposition": `attachment; filename="leads-${new Date().toISOString().slice(0, 10)}.csv"`,
        "cache-control": "no-store",
      },
    });
  } catch (e) {
    console.error("[leads:export]", e);
    return jsonError(502, "Falha ao exportar os leads.");
  }
}
