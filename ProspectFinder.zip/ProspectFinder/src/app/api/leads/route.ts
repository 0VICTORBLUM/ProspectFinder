import { NextResponse } from "next/server";
import { guard, jsonError } from "@/lib/api";
import { queryLeads } from "@/lib/lead-query";
import { getStore } from "@/lib/store";
import { flattenZodError, LeadQuerySchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const denied = await guard(req);
  if (denied) return denied;
  const params = Object.fromEntries(new URL(req.url).searchParams.entries());
  for (const k of Object.keys(params)) if (params[k] === "") delete params[k];
  const parsed = LeadQuerySchema.safeParse(params);
  if (!parsed.success) return jsonError(400, "Filtros inválidos.", flattenZodError(parsed.error));
  try {
    const store = getStore();
    const page = queryLeads(await store.listLeads(), parsed.data);
    return NextResponse.json({ ...page, persistence: { kind: store.kind, persistent: store.persistent } });
  } catch (e) {
    console.error("[leads:list]", e);
    return jsonError(502, "Falha ao ler os leads do armazenamento.");
  }
}
