import { NextResponse } from "next/server";
import { COOKIE_NAME, safeEqual, sha256Hex } from "@/lib/auth";
import { jsonError, readJson } from "@/lib/api";
import { clientKey, rateLimit } from "@/lib/rate-limit";

export async function POST(req: Request) {
  const rl = rateLimit(`auth:${clientKey(req)}`, 10, 60_000);
  if (!rl.ok) return jsonError(429, "Muitas tentativas. Aguarde um minuto.");
  const expected = process.env.APP_ACCESS_TOKEN;
  if (!expected) {
    return process.env.NODE_ENV === "production"
      ? jsonError(503, "APP_ACCESS_TOKEN não configurado.")
      : NextResponse.json({ ok: true, note: "Sem token configurado (modo desenvolvimento)." });
  }
  const body = await readJson(req);
  if (!body.ok) return body.res;
  const token = typeof (body.data as { token?: unknown }).token === "string" ? (body.data as { token: string }).token : "";
  if (!safeEqual(await sha256Hex(token), await sha256Hex(expected))) return jsonError(401, "Token incorreto.");
  const res = NextResponse.json({ ok: true });
  res.cookies.set(COOKIE_NAME, await sha256Hex(expected), {
    httpOnly: true, sameSite: "strict", secure: process.env.NODE_ENV === "production", path: "/", maxAge: 60 * 60 * 12,
  });
  return res;
}
