import { NextResponse } from "next/server";
import { guard } from "@/lib/api";
import { CONNECTORS } from "@/lib/connectors";
import { CNAE_CATALOG_VALIDATED, SEGMENTS } from "@/lib/segments";
import { getStore } from "@/lib/store";
import { MAX_LIMIT } from "@/lib/validation";

export async function GET(req: Request) {
  const denied = await guard(req);
  if (denied) return denied;
  const store = getStore();
  const sources = await Promise.all(
    Object.values(CONNECTORS).map(async (c) => ({ ...c!.meta, availability: await c!.availability() })),
  );
  return NextResponse.json({
    persistence: { kind: store.kind, persistent: store.persistent },
    sources,
    segments: Object.values(SEGMENTS),
    cnaeCatalogValidated: CNAE_CATALOG_VALIDATED,
    maxLimit: MAX_LIMIT,
  });
}
