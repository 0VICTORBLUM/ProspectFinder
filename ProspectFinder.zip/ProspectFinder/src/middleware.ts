import { NextResponse, type NextRequest } from "next/server";
import { decide, requestAuthInput } from "./lib/auth";

const PUBLIC = ["/login", "/api/auth"];

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  if (PUBLIC.some((p) => pathname === p)) return NextResponse.next();
  const result = await decide(requestAuthInput(req));
  if (result.ok) return NextResponse.next();
  if (pathname.startsWith("/api/")) {
    return NextResponse.json({ error: result.message }, { status: result.status });
  }
  if (result.status === 503) return new NextResponse(result.message, { status: 503 });
  const url = req.nextUrl.clone();
  url.pathname = "/login";
  url.search = "";
  return NextResponse.redirect(url);
}

export const config = { matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"] };
