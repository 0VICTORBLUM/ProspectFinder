import { describe, expect, it } from "vitest";
import { allocate, distributionReport } from "@/lib/distribution";
import { buildTasks } from "@/lib/search";
import { SearchRequestSchema } from "@/lib/validation";

describe("distribuição 70/30", () => {
  it("reparte o total e sempre soma o limite", () => {
    expect(allocate(100, { a: 70, b: 30 })).toEqual({ a: 70, b: 30 });
    expect(allocate(10, { a: 70, b: 30 })).toEqual({ a: 7, b: 3 });
    for (const n of [1, 3, 7, 33, 99, 500]) {
      const r = allocate(n, { a: 70, b: 30 });
      expect(r.a! + r.b!).toBe(n);
    }
    expect(allocate(5, { a: 0, b: 0 })).toEqual({ a: 0, b: 0 });
  });
  it("gera tarefas por segmento e respeita percentuais configurados", () => {
    const req = SearchRequestSchema.parse({ uf: "PR", sources: ["demo"], mode: "strategy", limit: 50, split: { impermeabilizacao: 50, construcao_a_seco: 50 } });
    expect(buildTasks(req).map((t) => [t.segment, t.target])).toEqual([["impermeabilizacao", 25], ["construcao_a_seco", 25]]);
    const manual = SearchRequestSchema.parse({ uf: "PR", sources: ["demo"], mode: "manual", segment: "distribuidores", limit: 40 });
    expect(buildTasks(manual)).toHaveLength(1);
  });
  it("não declara a meta cumprida quando não foi", () => {
    const rep = distributionReport({ a: 7, b: 3 }, { a: 7, b: 1 });
    expect(rep.find((r) => r.segment === "b")?.met).toBe(false);
    expect(rep.find((r) => r.segment === "a")?.achievedPct).toBe(88);
  });
});
