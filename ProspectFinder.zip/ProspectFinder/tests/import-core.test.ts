import { describe, expect, it } from "vitest";
// @ts-expect-error módulo .mjs sem tipos
import { E, EMP, estabToPartial, finalizeRecord, parseLine } from "../scripts/import-cnpj-core.mjs";

const estabLine = (over: Record<number, string> = {}) => {
  const f = Array(30).fill("");
  Object.assign(f, { [E.basico]: "11222333", [E.ordem]: "0001", [E.dv]: "81", [E.matriz]: "1", [E.fantasia]: "FANTASIA TESTE", [E.situacao]: "02", [E.cnaePrincipal]: "4330401", [E.cnaesSec]: "4399199,4330403", [E.uf]: "PR", [E.municipio]: "7535", [E.ddd1]: "41", [E.tel1]: "33334444", [E.email]: "Contato@Teste.com.br" }, over);
  return f.map((x: string) => `"${x}"`).join(";");
};
const ctx = { ufs: new Set(["PR"]), cnaes: new Set(["4330401"]), municipios: new Map([["7535", "CURITIBA"]]) };

describe("importador do CNPJ (dados sintéticos)", () => {
  it("interpreta campos com aspas e separadores", () => {
    expect(parseLine('"a";"b;c";"d""e"')).toEqual(["a", "b;c", 'd"e']);
  });
  it("seleciona por UF/CNAE e monta o registro", () => {
    const p = estabToPartial(parseLine(estabLine()), ctx);
    expect(p).toMatchObject({ cnpj: "11222333000181", city: "CURITIBA", matriz: true, cnaesSecundarios: ["4399199", "4330403"], email: "contato@teste.com.br" });
    expect(estabToPartial(parseLine(estabLine({ [E.uf]: "RJ" })), ctx)).toBeNull();
    expect(estabToPartial(parseLine(estabLine({ [E.cnaePrincipal]: "4711302", [E.cnaesSec]: "" })), ctx)).toBeNull();
    expect(estabToPartial(parseLine(estabLine({ [E.cnaePrincipal]: "4711302", [E.cnaesSec]: "4330401" })), ctx)).not.toBeNull();
  });
  it("junta a razão social e remove e-mail de empresário individual (minimização)", () => {
    const p = estabToPartial(parseLine(estabLine()), ctx);
    const emp = (nat: string) => { const f = Array(7).fill(""); f[EMP.basico] = "11222333"; f[EMP.razao] = "EMPRESA TESTE LTDA"; f[EMP.natureza] = nat; return f; };
    expect(finalizeRecord(p, emp("2062")).email).toBe("contato@teste.com.br");
    expect(finalizeRecord(p, emp("2135")).email).toBeNull();
    expect(finalizeRecord(p, emp("2062")).razaoSocial).toBe("EMPRESA TESTE LTDA");
  });
});
