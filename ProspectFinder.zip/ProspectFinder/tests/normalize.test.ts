import { describe, expect, it } from "vitest";
import {
  formatCnpj, isValidCnpj, normalizeCity, normalizeCnae, normalizeCnpj, normalizeCompanyName, normalizePhone,
  normalizeUf, normalizeWebsite,
} from "@/lib/normalize";
import { makeCnpj } from "./helpers/fixtures";

describe("CNPJ", () => {
  it("normaliza e formata", () => {
    const c = makeCnpj("112223330001");
    expect(normalizeCnpj(formatCnpj(c))).toBe(c);
    expect(formatCnpj(c)).toMatch(/^\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}$/);
    expect(normalizeCnpj("123")).toBeNull();
  });
  it("valida dígitos verificadores", () => {
    expect(isValidCnpj(makeCnpj("112223330001"))).toBe(true);
    expect(isValidCnpj("11222333000100")).toBe(false);
    expect(isValidCnpj("00000000000000")).toBe(false);
    expect(isValidCnpj(null)).toBe(false);
  });
});

describe("telefone", () => {
  it("normaliza fixo e móvel, com DDD separado ou +55", () => {
    expect(normalizePhone("(41) 3333-4444")?.formatted).toBe("(41) 3333-4444");
    expect(normalizePhone("33334444", "41")?.digits).toBe("4133334444");
    expect(normalizePhone("+55 41 99999-8888")).toMatchObject({ formatted: "(41) 99999-8888", type: "movel" });
    expect(normalizePhone("041 3333-4444")?.digits).toBe("4133334444");
  });
  it("rejeita inválidos", () => {
    expect(normalizePhone("12345")).toBeNull();
    expect(normalizePhone("41 8888-77777")).toBeNull();
    expect(normalizePhone("(41) 1333-4444")).toBeNull(); // fixo não começa com 1
    expect(normalizePhone("(41) 89999-8888")).toBeNull(); // móvel precisa do 9
    expect(normalizePhone("(00) 3333-4444")).toBeNull();
    expect(normalizePhone(null)).toBeNull();
  });
});

describe("nomes, UF, cidade, CNAE, website", () => {
  it("normaliza nomes removendo sufixos legais e acentos", () => {
    expect(normalizeCompanyName("Impermeabilização & Cia Ltda.")).toBe("IMPERMEABILIZACAO E");
    expect(normalizeCompanyName("  ACME   S/A ")).toBe("ACME");
  });
  it("normaliza UF e cidade", () => {
    expect(normalizeUf(" pr ")).toBe("PR");
    expect(normalizeUf("XX")).toBeNull();
    expect(normalizeCity("São José dos Pinhais")).toBe("SAO JOSE DOS PINHAIS");
  });
  it("normaliza CNAE e website", () => {
    expect(normalizeCnae("4330-4/01")).toBe("4330401");
    expect(normalizeCnae("43304")).toBeNull();
    expect(normalizeWebsite("WWW.Exemplo.com.br/contato")).toBe("https://exemplo.com.br");
    expect(normalizeWebsite("semponto")).toBeNull();
  });
});
