import { describe, expect, it } from "vitest";
import { sanitizeCsvCell, toCsv } from "@/lib/csv";
import { paginate } from "@/lib/paginate";
import { filterLeads, queryLeads } from "@/lib/lead-query";
import { LeadQuerySchema } from "@/lib/validation";
import { lead, makeCnpj } from "./helpers/fixtures";

describe("CSV seguro", () => {
  it("neutraliza fórmulas", () => {
    for (const v of ["=1+1", "+cmd", "-2+3", "@SUM(A1)", "\tTAB", "\rCR"]) {
      expect(sanitizeCsvCell(v).replace(/^"/, "").startsWith("'")).toBe(true);
    }
    expect(sanitizeCsvCell("Empresa normal")).toBe("Empresa normal");
    expect(sanitizeCsvCell(95)).toBe("95");
  });
  it("escapa aspas, separador e quebras de linha", () => {
    expect(sanitizeCsvCell('a;"b"')).toBe('"a;""b"""');
    expect(sanitizeCsvCell("linha1\nlinha2")).toBe('"linha1\nlinha2"');
  });
  it("gera BOM, separador ; e CRLF", () => {
    const csv = toCsv(["A", "B"], [["=HYPERLINK(\"x\")", "ok"]]);
    expect(csv.startsWith("\uFEFFA;B\r\n")).toBe(true);
    expect(csv).toContain("\"'=HYPERLINK(\"\"x\"\")\";ok");
  });
});

describe("paginação", () => {
  const items = Array.from({ length: 53 }, (_, i) => i);
  it("calcula páginas e limita valores", () => {
    expect(paginate(items, 1, 25)).toMatchObject({ total: 53, totalPages: 3, page: 1 });
    expect(paginate(items, 3, 25).items).toHaveLength(3);
    expect(paginate(items, 99, 25).page).toBe(3);
    expect(paginate(items, -4, 25).page).toBe(1);
    expect(paginate(items, 1, 9999).pageSize).toBe(200);
    expect(paginate([], 1, 25)).toMatchObject({ totalPages: 1, items: [] });
  });
});

describe("consulta de leads", () => {
  const leads = [
    lead({ razaoSocial: "ALFA", cnpj: makeCnpj("111111110001"), city: "Curitiba" }),
    lead({ razaoSocial: "BETA", cnpj: makeCnpj("222222220001"), city: "Joinville", uf: "SC" }),
    lead({ razaoSocial: "GAMA", cnpj: makeCnpj("333333330001"), city: "Joinville", uf: "SC" }, "construcao_a_seco"),
  ];
  const q = (o: object) => LeadQuerySchema.parse(o);
  it("filtra por texto, CNPJ, UF, cidade e segmento", () => {
    expect(filterLeads(leads, q({ q: "alf" }))).toHaveLength(1);
    expect(filterLeads(leads, q({ q: leads[1]!.cnpj!.slice(0, 8) }))).toHaveLength(1);
    expect(filterLeads(leads, q({ uf: "SC" }))).toHaveLength(2);
    expect(filterLeads(leads, q({ city: "joinville", segment: "construcao_a_seco" }))).toHaveLength(1);
  });
  it("ordena e pagina", () => {
    const page = queryLeads(leads, q({ sort: "razaoSocial", dir: "desc", pageSize: 2 }));
    expect(page.items.map((l) => l.razaoSocial)).toEqual(["GAMA", "BETA"]);
    expect(page.totalPages).toBe(2);
  });
});
