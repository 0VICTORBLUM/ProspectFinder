import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { decide, sha256Hex, COOKIE_NAME } from "@/lib/auth";
import { setStoreForTests } from "@/lib/store";
import { MemoryStore } from "@/lib/store/memory";
import { GET as listLeads } from "@/app/api/leads/route";
import { GET as getLead, PATCH as patchLead } from "@/app/api/leads/[id]/route";
import { GET as exportLeads } from "@/app/api/leads/export/route";
import { POST as createSearch } from "@/app/api/searches/route";
import { POST as step } from "@/app/api/searches/[id]/step/route";
import { GET as getConfig } from "@/app/api/config/route";
import { lead } from "./helpers/fixtures";

const TOKEN = "token-de-teste-bem-longo";
const env = process.env as Record<string, string | undefined>;
const call = (url: string, init: RequestInit = {}, token: string | null = TOKEN) =>
  new Request(`http://localhost${url}`, { ...init, headers: { "content-type": "application/json", ...(token ? { authorization: `Bearer ${token}` } : {}), ...(init.headers ?? {}) } });
const ctx = (id: string) => ({ params: Promise.resolve({ id }) });

let store: MemoryStore;
beforeEach(() => {
  env.APP_ACCESS_TOKEN = TOKEN;
  env.ENABLE_DEMO_SOURCE = "true";
  store = new MemoryStore();
  setStoreForTests(store);
});
afterEach(() => { delete env.APP_ACCESS_TOKEN; setStoreForTests(undefined); });

describe("decisão de autenticação", () => {
  it("aceita Bearer e cookie com hash; recusa o resto", async () => {
    const base = { token: TOKEN, nodeEnv: "production", authorization: null, cookie: undefined };
    expect((await decide({ ...base, authorization: `Bearer ${TOKEN}` })).ok).toBe(true);
    expect((await decide({ ...base, cookie: await sha256Hex(TOKEN) })).ok).toBe(true);
    expect(await decide({ ...base, cookie: TOKEN })).toMatchObject({ ok: false, status: 401 });
    expect(await decide({ ...base, authorization: "Bearer errado" })).toMatchObject({ ok: false, status: 401 });
    expect(await decide(base)).toMatchObject({ ok: false, status: 401 });
  });
  it("falha fechada em produção sem token; libera em desenvolvimento", async () => {
    const base = { token: undefined, authorization: null, cookie: undefined };
    expect(await decide({ ...base, nodeEnv: "production" })).toMatchObject({ ok: false, status: 503 });
    expect((await decide({ ...base, nodeEnv: "development" })).ok).toBe(true);
  });
  it("o nome do cookie é estável", () => expect(COOKIE_NAME).toBe("pf_session"));
});

describe("permissões dos endpoints", () => {
  it("todos exigem autenticação", async () => {
    const id = "cnpj-1";
    const res = await Promise.all([
      listLeads(call("/api/leads", {}, null)),
      getLead(call(`/api/leads/${id}`, {}, null), ctx(id)),
      patchLead(call(`/api/leads/${id}`, { method: "PATCH", body: "{}" }, null), ctx(id)),
      exportLeads(call("/api/leads/export", {}, null)),
      createSearch(call("/api/searches", { method: "POST", body: "{}" }, null)),
      step(call(`/api/searches/${id}/step`, { method: "POST" }, null), ctx(id)),
      getConfig(call("/api/config", {}, null)),
    ]);
    expect(res.map((r) => r.status)).toEqual(Array(7).fill(401));
  });
  it("token errado é recusado", async () => {
    expect((await listLeads(call("/api/leads", {}, "outro"))).status).toBe(401);
  });
});

describe("endpoints com autenticação", () => {
  it("PATCH altera só campos comerciais e rejeita os demais", async () => {
    const l = lead();
    await store.upsertLeads([l]);
    const ok = await patchLead(call(`/api/leads/${l.id}`, { method: "PATCH", body: JSON.stringify({ status: "contatado", notes: "ok" }) }), ctx(l.id));
    expect(ok.status).toBe(200);
    expect((await ok.json()).persisted).toBe(false); // memória: nunca apresentado como persistido
    expect((await store.getLead(l.id))?.status).toBe("contatado");
    const bad = await patchLead(call(`/api/leads/${l.id}`, { method: "PATCH", body: JSON.stringify({ score: 100, razaoSocial: "X" }) }), ctx(l.id));
    expect(bad.status).toBe(400);
    expect((await store.getLead(l.id))?.score).toBe(l.score);
  });
  it("valida ids, filtros e JSON", async () => {
    expect((await getLead(call("/api/leads/../etc"), ctx("../etc"))).status).toBe(400);
    expect((await getLead(call("/api/leads/cnpj-999"), ctx("cnpj-999"))).status).toBe(404);
    expect((await listLeads(call("/api/leads?uf=ZZ"))).status).toBe(400);
    expect((await createSearch(call("/api/searches", { method: "POST", body: "{quebrado" }))).status).toBe(400);
    expect((await createSearch(call("/api/searches", { method: "POST", body: JSON.stringify({ uf: "PR", sources: ["http://interno"] }) }))).status).toBe(400);
    expect((await createSearch(call("/api/searches", { method: "POST", body: "x".repeat(40_000) }))).status).toBe(413);
  });
  it("fluxo completo: criar, executar lotes, listar e exportar CSV seguro", async () => {
    const created = await createSearch(call("/api/searches", { method: "POST", body: JSON.stringify({ uf: "SC", sources: ["demo"], limit: 3, segment: "impermeabilizacao" }) }));
    expect(created.status).toBe(201);
    const s = await created.json();
    expect(s.dataMode).toBe("demonstracao");
    let state = s;
    for (let i = 0; i < 10 && state.status !== "concluida"; i++) state = await (await step(call(`/api/searches/${s.id}/step`, { method: "POST" }), ctx(s.id))).json();
    expect(state.status).toBe("concluida");
    const list = await (await listLeads(call(`/api/leads?searchId=${s.id}&sort=score&dir=desc`))).json();
    expect(list.total).toBe(3);
    expect(list.persistence.persistent).toBe(false);
    await store.upsertLeads([{ ...(await store.listLeads())[0]!, notes: "=cmd|' /C calc'!A0" }]);
    const res = await exportLeads(call("/api/leads/export"));
    const bytes = new Uint8Array(await res.clone().arrayBuffer());
    expect([...bytes.slice(0, 3)]).toEqual([0xef, 0xbb, 0xbf]); // BOM UTF-8 para o Excel
    const csv = await res.text();
    expect(csv).toContain(";'=cmd|' /C calc'!A0;sim"); // prefixo ' neutraliza a fórmula
  });
});
