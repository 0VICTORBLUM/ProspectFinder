import { buildLead } from "@/lib/leads";
import type { Lead, RawCompany } from "@/lib/types";

/** Gera um CNPJ com dígitos verificadores válidos a partir de 12 dígitos (dados de teste, não reais). */
export function makeCnpj(base12: string): string {
  const calc = (b: string, w: number[]) => {
    const r = b.split("").reduce((a, c, i) => a + Number(c) * w[i]!, 0) % 11;
    return r < 2 ? 0 : 11 - r;
  };
  const d1 = calc(base12, [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]);
  const d2 = calc(base12 + d1, [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]);
  return `${base12}${d1}${d2}`;
}

export const raw = (over: Partial<RawCompany> = {}): RawCompany => ({
  cnpj: makeCnpj("112223330001"),
  razaoSocial: "TESTE IMPERMEABILIZACOES LTDA",
  nomeFantasia: "Teste Imper",
  city: "Curitiba",
  uf: "PR",
  ddd: "41",
  phone: "33334444",
  email: "contato@testeimper.com.br",
  cnaePrincipal: "4330401",
  cnaesSecundarios: [],
  situacaoCadastral: "Ativa",
  matriz: true,
  source: "cnpj-local",
  ...over,
});

export function lead(over: Partial<RawCompany> = {}, segment: "impermeabilizacao" | "construcao_a_seco" = "impermeabilizacao"): Lead {
  const r = buildLead(raw(over), segment, "s1", "2026-01-01T00:00:00.000Z");
  if (!r.ok) throw new Error(`fixture inválida: ${r.reason}`);
  return r.lead;
}
