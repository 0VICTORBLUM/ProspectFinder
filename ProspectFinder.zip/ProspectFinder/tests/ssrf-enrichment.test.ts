import { describe, expect, it } from "vitest";
import { assertPublicUrl, isPrivateIp, safeFetchText, UnsafeUrlError } from "@/lib/ssrf";
import { enrichLead, extractFacts, inferWebsiteFromEmail, isAllowedByRobots, siteConfirmsCompany } from "@/lib/enrichment";
import { lead } from "./helpers/fixtures";

const pub = async () => ["93.184.216.34"];

describe("SSRF", () => {
  it("identifica IPs privados e reservados", () => {
    for (const ip of ["127.0.0.1", "10.0.0.5", "192.168.1.1", "172.16.0.1", "169.254.169.254", "100.64.0.1", "::1", "fd00::1", "fe80::1", "::ffff:127.0.0.1"]) {
      expect(isPrivateIp(ip), ip).toBe(true);
    }
    expect(isPrivateIp("93.184.216.34")).toBe(false);
    expect(isPrivateIp("2606:2800:220:1::1")).toBe(false);
  });
  it("bloqueia protocolos, credenciais, portas e hosts internos", async () => {
    for (const u of ["file:///etc/passwd", "ftp://x.com", "http://user:pw@x.com", "http://x.com:8080", "http://localhost", "http://127.0.0.1", "http://[::1]", "http://srv.internal", "não é url"]) {
      await expect(assertPublicUrl(u, pub), u).rejects.toBeInstanceOf(UnsafeUrlError);
    }
    await expect(assertPublicUrl("https://exemplo.com.br", pub)).resolves.toBeInstanceOf(URL);
  });
  it("bloqueia domínio que resolve para IP interno (rebinding simples)", async () => {
    await expect(assertPublicUrl("https://evil.example", async () => ["10.0.0.1"])).rejects.toBeInstanceOf(UnsafeUrlError);
    await expect(assertPublicUrl("https://evil.example", async () => ["93.184.216.34", "127.0.0.1"])).rejects.toBeInstanceOf(UnsafeUrlError);
  });
  it("revalida cada redirecionamento", async () => {
    const f = (async (url: string) =>
      url.includes("a.example")
        ? new Response(null, { status: 302, headers: { location: "http://169.254.169.254/latest/meta-data" } })
        : new Response("ok")) as unknown as typeof fetch;
    await expect(safeFetchText("https://a.example", { timeoutMs: 1000, maxBytes: 1000, userAgent: "t", fetchImpl: f, resolver: pub })).rejects.toBeInstanceOf(UnsafeUrlError);
  });
  it("limita o tamanho lido", async () => {
    const f = (async () => new Response("x".repeat(5000), { headers: { "content-type": "text/html" } })) as unknown as typeof fetch;
    const r = await safeFetchText("https://a.example", { timeoutMs: 1000, maxBytes: 1000, userAgent: "t", fetchImpl: f, resolver: pub });
    expect(r.text.length).toBeLessThan(5000);
  });
});

describe("robots.txt", () => {
  it("respeita Disallow geral e específico", () => {
    expect(isAllowedByRobots("User-agent: *\nDisallow: /", "ProspectFinderBot", "/")).toBe(false);
    expect(isAllowedByRobots("User-agent: *\nDisallow: /admin", "ProspectFinderBot", "/")).toBe(true);
    expect(isAllowedByRobots("User-agent: ProspectFinderBot\nDisallow: /\n\nUser-agent: *\nAllow: /", "ProspectFinderBot", "/")).toBe(false);
    expect(isAllowedByRobots("User-agent: *\nDisallow:", "ProspectFinderBot", "/")).toBe(true);
    expect(isAllowedByRobots("", "ProspectFinderBot", "/")).toBe(true);
  });
});

describe("enriquecimento", () => {
  const html = (body: string) => `<html><head><title>Teste Imper</title><meta name="description" content="Impermeabilização de lajes e piscinas"></head><body>${body}<a href="tel:+554133334444">ligue</a><a href="mailto:Vendas@testeimper.com.br">e-mail</a></body></html>`;
  const mkFetch = (page: string, robots = "User-agent: *\nDisallow:") =>
    (async (url: string) =>
      url.endsWith("/robots.txt")
        ? new Response(robots, { headers: { "content-type": "text/plain" } })
        : new Response(page, { headers: { "content-type": "text/html" } })) as unknown as typeof fetch;

  it("infere website só de domínio corporativo e marca como inferido", () => {
    expect(inferWebsiteFromEmail("a@gmail.com")).toBeNull();
    expect(inferWebsiteFromEmail("a@empresa.com.br")).toBe("https://empresa.com.br");
  });
  it("extrai fatos e confirma a empresa pelo nome ou CNPJ", () => {
    const l = lead();
    const f = extractFacts(html("<p>Bem-vindo à Teste Imper</p>"));
    expect(f.phones).toEqual(["+554133334444"]);
    expect(siteConfirmsCompany(f, l)).toBe(true);
    expect(siteConfirmsCompany(extractFacts(html("<p>Outra empresa</p>").replace("Teste Imper", "Outra")), l)).toBe(false);
  });
  it("promove website inferido a verificado e acrescenta evidência quando confirmado", async () => {
    const l = lead({ website: "https://testeimper.com.br", websiteInferred: true });
    const out = await enrichLead(l, { segment: "impermeabilizacao", fetchImpl: mkFetch(html("<p>Teste Imper</p>")), resolver: pub });
    expect(out.status).toBe("enriquecido");
    expect(out.lead.provenance["website"]?.confidence).toBe("verified");
    expect(out.lead.siteEvidence.length).toBe(1);
  });
  it("não pontua nem usa dados de site não confirmado", async () => {
    const l = lead({ website: "https://outro.com", websiteInferred: true, phone: null, ddd: null });
    const out = await enrichLead(l, { segment: "impermeabilizacao", fetchImpl: mkFetch(html("<p>Empresa diferente</p>").replace("Teste Imper", "Diferente")), resolver: pub });
    expect(out.lead.provenance["website"]?.confidence).toBe("inferred");
    expect(out.lead.phone).toBeNull();
  });
  it("não coleta quando robots.txt proíbe e trata falhas sem quebrar", async () => {
    const l = lead({ website: "https://testeimper.com.br" });
    const blocked = await enrichLead(l, { segment: "impermeabilizacao", fetchImpl: mkFetch(html(""), "User-agent: *\nDisallow: /"), resolver: pub });
    expect(blocked).toMatchObject({ status: "ignorado", reason: "bloqueado por robots.txt" });
    const boom = await enrichLead(l, { segment: "impermeabilizacao", fetchImpl: (async () => { throw new Error("x"); }) as unknown as typeof fetch, resolver: pub });
    expect(boom.status).toBe("ignorado");
    const internal = await enrichLead(lead({ website: "http://192.168.0.10" }), { segment: "impermeabilizacao", fetchImpl: mkFetch(""), resolver: pub });
    expect(internal.status).toBe("ignorado");
  });
});
