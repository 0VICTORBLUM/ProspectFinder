import { describe, expect, it } from "vitest";
import { qualify } from "@/lib/scoring";
import { lead } from "./helpers/fixtures";

const ctx = { segment: "impermeabilizacao" as const, targetUfs: ["PR" as const] };

describe("pontuação", () => {
  it("é explicável e soma só critérios atendidos", () => {
    const r = qualify(lead(), ctx);
    expect(r.breakdown.map((b) => b.id)).toEqual(["cnae", "nome", "site", "regiao", "website", "telefone", "canal"]);
    expect(r.score).toBe(r.breakdown.reduce((a, b) => a + b.points, 0));
    expect(r.score).toBeGreaterThanOrEqual(40 + 10 + 10 + 5); // cnae + nome + região + telefone
    expect(r.score).toBeLessThanOrEqual(100);
  });
  it("marca como desconhecido em vez de inferir resultado positivo", () => {
    const r = qualify(lead({ cnaePrincipal: null, phone: null, website: null, uf: null }), ctx);
    const byId = Object.fromEntries(r.breakdown.map((b) => [b.id, b]));
    expect(byId["cnae"]?.status).toBe("unknown");
    expect(byId["site"]?.status).toBe("unknown");
    expect(byId["regiao"]?.status).toBe("unknown");
    expect(byId["website"]?.status).toBe("unknown");
    expect(r.score).toBeLessThan(25);
  });
  it("nome com palavra-chave sozinho não faz a empresa 'especializada'", () => {
    const r = qualify(lead({ razaoSocial: "IMPERMEABILIZACAO FANTASMA LTDA", cnaePrincipal: "4711302", phone: null }), ctx);
    expect(r.score).toBeLessThanOrEqual(20);
  });
  it("website inferido não pontua e evidência de site só conta após confirmação", () => {
    const l = lead({ website: "https://testeimper.com.br", websiteInferred: true });
    l.siteEvidence = ["Impermeabilização de lajes"];
    const r = qualify(l, ctx);
    expect(r.breakdown.find((b) => b.id === "website")?.points).toBe(0);
    expect(r.breakdown.find((b) => b.id === "site")?.points).toBe(0);
    l.provenance["website"] = { source: "website", confidence: "verified", updatedAt: "x" };
    const r2 = qualify(l, ctx);
    expect(r2.breakdown.find((b) => b.id === "site")?.points).toBe(20);
    expect(r2.score).toBeGreaterThan(r.score);
  });
  it("região fora da pesquisa não pontua", () => {
    expect(qualify(lead({ uf: "SP" }), ctx).breakdown.find((b) => b.id === "regiao")?.status).toBe("unmet");
  });
  it("distribuidores pontuam como canal pelo CNAE de comércio", () => {
    const r = qualify(lead({ cnaePrincipal: "4679699" }), { segment: "distribuidores", targetUfs: ["PR"] });
    expect(r.breakdown.find((b) => b.id === "canal")?.points).toBe(10);
  });
});
