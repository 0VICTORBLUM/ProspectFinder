import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { cnpjLocalConnector, matchesQuery, type CnpjRecord } from "@/lib/connectors/cnpj-local";
import type { ConnectorQuery } from "@/lib/connectors/types";
import { SearchRequestSchema } from "@/lib/validation";
import { makeCnpj } from "./helpers/fixtures";

const rec = (i: number, over: Partial<CnpjRecord> = {}): CnpjRecord => ({
  cnpj: makeCnpj(String(700000000001 + i * 10)), razaoSocial: `EMPRESA TESTE ${i} LTDA`, nomeFantasia: null, situacao: "02", matriz: true,
  cnaePrincipal: "4330401", cnaesSecundarios: [], uf: "PR", city: "CURITIBA", ddd: "41", phone: "33334444", email: null, ...over,
});

let dir = "";
const q = (o: Partial<ConnectorQuery> = {}, reqOver: object = {}): ConnectorQuery => ({
  segment: "impermeabilizacao",
  request: SearchRequestSchema.parse({ uf: "PR", sources: ["cnpj-local"], ...reqOver }),
  cnaes: ["4330401"], keywords: ["impermeabiliza"], cursor: 0, batchSize: 50, deadline: Date.now() + 5000, ...o,
});

beforeAll(() => {
  dir = mkdtempSync(path.join(tmpdir(), "pf-"));
  const rows = [
    ...Array.from({ length: 120 }, (_, i) => rec(i)),
    rec(200, { uf: "SP" }),
    rec(201, { situacao: "08" }),
    rec(202, { cnaePrincipal: "4711302", razaoSocial: "MERCADO SEM RELACAO" }),
    rec(203, { cnaePrincipal: "4711302", razaoSocial: "SOLUCOES EM IMPERMEABILIZACAO ME" }),
  ];
  writeFileSync(path.join(dir, "e.jsonl"), rows.map((r) => JSON.stringify(r)).join("\n")); // sem newline final
  process.env.CNPJ_DATA_FILE = path.join(dir, "e.jsonl");
});
afterAll(() => rmSync(dir, { recursive: true, force: true }));

describe("conector CNPJ local", () => {
  it("filtra por UF, situação, CNAE e palavra-chave", () => {
    expect(matchesQuery(rec(1, { uf: "SP" }), q())).toBe(false);
    expect(matchesQuery(rec(1, { situacao: "08" }), q())).toBe(false);
    expect(matchesQuery(rec(1, { situacao: "08" }), q({}, { situacao: "todas" }))).toBe(true);
    expect(matchesQuery(rec(1, { cnaePrincipal: "4711302" }), q())).toBe(false);
    expect(matchesQuery(rec(1, { cnaePrincipal: "4711302", cnaesSecundarios: ["4330401"] }), q())).toBe(true);
    expect(matchesQuery(rec(1, { city: "Londrina" }), q({}, { cities: ["curitiba"] }))).toBe(false);
  });
  it("lê em lotes com cursor, sem perder nem repetir registros", async () => {
    const seen = new Set<string>();
    let cursor = 0;
    for (let i = 0; i < 20; i++) {
      const page = await cnpjLocalConnector.search(q({ cursor, batchSize: 25 }));
      page.records.forEach((r) => seen.add(r.cnpj!));
      cursor = page.nextCursor;
      if (page.done) break;
    }
    expect(seen.size).toBe(121); // 120 + a que casa só por palavra-chave no nome
  });
  it("informa indisponibilidade quando o arquivo não existe", async () => {
    const old = process.env.CNPJ_DATA_FILE;
    process.env.CNPJ_DATA_FILE = path.join(dir, "nao-existe.jsonl");
    const a = await cnpjLocalConnector.availability();
    expect(a.state).toBe("unavailable");
    process.env.CNPJ_DATA_FILE = old;
    expect((await cnpjLocalConnector.availability()).state).toBe("available");
  });
});
