import { describe, expect, it } from "vitest";
import { LeadPatchSchema, SearchRequestSchema } from "@/lib/validation";

const base = { uf: "PR", sources: ["demo"] };

describe("SearchRequestSchema", () => {
  it("aplica padrões e normaliza CNAEs", () => {
    const r = SearchRequestSchema.parse({ ...base, cnaes: ["4330-4/01", "4330401"] });
    expect(r.limit).toBe(50);
    expect(r.situacao).toBe("ativa");
    expect(r.cnaes).toEqual(["4330401"]);
  });
  it("rejeita CNAE inválido, UF inexistente e limite fora da faixa", () => {
    expect(SearchRequestSchema.safeParse({ ...base, cnaes: ["123"] }).success).toBe(false);
    expect(SearchRequestSchema.safeParse({ ...base, uf: "ZZ" }).success).toBe(false);
    expect(SearchRequestSchema.safeParse({ ...base, limit: 0 }).success).toBe(false);
    expect(SearchRequestSchema.safeParse({ ...base, limit: 100000 }).success).toBe(false);
  });
  it("exige fonte e soma 100 na estratégia", () => {
    expect(SearchRequestSchema.safeParse({ uf: "PR", sources: [] }).success).toBe(false);
    const bad = SearchRequestSchema.safeParse({ ...base, mode: "strategy", split: { impermeabilizacao: 60, construcao_a_seco: 30 } });
    expect(bad.success).toBe(false);
    expect(SearchRequestSchema.safeParse({ ...base, mode: "strategy", split: { impermeabilizacao: 70, construcao_a_seco: 30 } }).success).toBe(true);
  });
  it("não permite cidades com Brasil inteiro e exige critérios no segmento livre", () => {
    expect(SearchRequestSchema.safeParse({ ...base, uf: "BR", cities: ["Curitiba"] }).success).toBe(false);
    expect(SearchRequestSchema.safeParse({ ...base, segment: "outro" }).success).toBe(false);
    expect(SearchRequestSchema.safeParse({ ...base, segment: "outro", keywords: ["telha"] }).success).toBe(true);
  });
  it("rejeita fontes desconhecidas (inclusive tentativa de URL arbitrária)", () => {
    expect(SearchRequestSchema.safeParse({ ...base, sources: ["http://interno"] }).success).toBe(false);
  });
});

describe("LeadPatchSchema", () => {
  it("só permite status e observações", () => {
    expect(LeadPatchSchema.safeParse({ status: "contatado" }).success).toBe(true);
    expect(LeadPatchSchema.safeParse({ notes: "ok" }).success).toBe(true);
    expect(LeadPatchSchema.safeParse({ score: 100 }).success).toBe(false);
    expect(LeadPatchSchema.safeParse({ status: "inventado" }).success).toBe(false);
    expect(LeadPatchSchema.safeParse({}).success).toBe(false);
  });
});
