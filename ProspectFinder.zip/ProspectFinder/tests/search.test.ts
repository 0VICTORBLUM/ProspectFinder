import { describe, expect, it } from "vitest";
import type { Connector } from "@/lib/connectors/types";
import { demoConnector } from "@/lib/connectors/demo";
import { cancelSearch, createSearch, stepSearch, type SearchDeps } from "@/lib/search";
import { MemoryStore } from "@/lib/store/memory";
import { StoreError, type LeadStore } from "@/lib/store/types";
import type { RawCompany, SearchRequest, SearchResult, SourceId } from "@/lib/types";
import { SearchRequestSchema } from "@/lib/validation";
import { makeCnpj, raw } from "./helpers/fixtures";

const req = (o: object = {}): SearchRequest => SearchRequestSchema.parse({ uf: "PR", sources: ["cnpj-local"], mode: "manual", segment: "impermeabilizacao", limit: 5, ...o });

function fake(records: RawCompany[], opts: { available?: boolean; throwAt?: number } = {}): Connector {
  return {
    meta: { id: "cnpj-local", label: "Fonte falsa", description: "", demo: false },
    availability: async () => (opts.available === false ? { state: "unavailable", reason: "fora do ar" } : { state: "available" }),
    async search(q) {
      if (opts.throwAt !== undefined && q.cursor >= opts.throwAt) throw new Error("fonte caiu");
      const slice = records.slice(q.cursor, q.cursor + q.batchSize);
      const next = q.cursor + slice.length;
      return { records: slice, nextCursor: next, done: next >= records.length, scanned: slice.length };
    },
  };
}
const withConnectors = (store: LeadStore, map: Partial<Record<SourceId, Connector>>): SearchDeps => ({ store, connector: (id) => map[id] });
const companies = (n: number, over: Partial<RawCompany> = {}) =>
  Array.from({ length: n }, (_, i) => raw({ cnpj: makeCnpj(String(500000000001 + i * 10)), razaoSocial: `EMPRESA ${i} LTDA`, ...over }));

async function runAll(id: string, deps: SearchDeps): Promise<SearchResult> {
  let s = (await stepSearch(id, deps))!;
  for (let i = 0; i < 50 && !["concluida", "parcial", "erro", "cancelada"].includes(s.status); i++) s = (await stepSearch(id, deps))!;
  return s;
}

describe("execução da pesquisa", () => {
  it("encontra, pontua, grava e para na meta", async () => {
    const store = new MemoryStore();
    const deps = withConnectors(store, { "cnpj-local": fake(companies(20)) });
    const s = await createSearch(req({ limit: 5 }), deps);
    const done = await runAll(s.id, deps);
    expect(done.status).toBe("concluida");
    expect(done.counts.saved).toBe(5);
    const leads = await store.listLeads();
    expect(leads).toHaveLength(5);
    expect(leads[0]?.score).toBeGreaterThan(0);
    expect(leads[0]?.scoreBreakdown.length).toBeGreaterThan(0);
  });
  it("detecta duplicatas e não duplica ao repetir a pesquisa", async () => {
    const store = new MemoryStore();
    const deps = withConnectors(store, { "cnpj-local": fake(companies(3)) });
    await runAll((await createSearch(req(), deps)).id, deps);
    const second = await runAll((await createSearch(req(), deps)).id, deps);
    expect(second.counts.saved).toBe(0);
    expect(second.counts.duplicates).toBe(3);
    expect(await store.listLeads()).toHaveLength(3);
  });
  it("descarta CNPJ inválido e registra o motivo", async () => {
    const store = new MemoryStore();
    const bad = raw({ cnpj: "11222333000100", razaoSocial: "INVALIDA" });
    const deps = withConnectors(store, { "cnpj-local": fake([bad, ...companies(2)]) });
    const done = await runAll((await createSearch(req(), deps)).id, deps);
    expect(done.counts.discarded).toBe(1);
    expect(done.discardReasons["cnpj_invalido"]).toBe(1);
    expect(done.counts.saved).toBe(2);
  });
  it("avisa quando a meta não é atingida, sem afirmar cumprimento", async () => {
    const store = new MemoryStore();
    const deps = withConnectors(store, { "cnpj-local": fake(companies(2)) });
    const done = await runAll((await createSearch(req({ limit: 10 }), deps)).id, deps);
    expect(done.status).toBe("concluida");
    expect(done.warnings.join(" ")).toMatch(/não atingida: 2 de 10/);
  });
  it("estratégia 70/30 cria uma tarefa por segmento", async () => {
    const store = new MemoryStore();
    const deps = withConnectors(store, { demo: demoConnector });
    const s = await createSearch(req({ mode: "strategy", sources: ["demo"], uf: "BR", limit: 10 }), deps);
    expect(s.tasks.map((t) => [t.segment, t.target])).toEqual([["impermeabilizacao", 7], ["construcao_a_seco", 3]]);
    const done = await runAll(s.id, deps);
    const leads = await store.listLeads();
    expect(leads.filter((l) => l.segment === "impermeabilizacao")).toHaveLength(7);
    expect(leads.filter((l) => l.segment === "construcao_a_seco")).toHaveLength(3);
    expect(done.counts.saved).toBe(10);
  });
});

describe("transparência: real × demonstração × erro", () => {
  it("marca dados fictícios e avisa que só há memória", async () => {
    const store = new MemoryStore();
    const deps = withConnectors(store, { demo: demoConnector });
    const s = await createSearch(req({ sources: ["demo"] }), deps);
    expect(s.dataMode).toBe("demonstracao");
    expect(s.persistence).toBe("memoria");
    expect(s.warnings.join(" ")).toMatch(/FICTÍCIOS/);
    expect(s.warnings.join(" ")).toMatch(/apenas em memória/);
    const done = await runAll(s.id, deps);
    expect((await store.listLeads()).every((l) => l.isDemo)).toBe(true);
    expect(done.counts.saved).toBeGreaterThan(0);
  });
  it("fonte indisponível: erro explícito e nada é pesquisado", async () => {
    const deps = withConnectors(new MemoryStore(), { "cnpj-local": fake([], { available: false }) });
    const s = await createSearch(req(), deps);
    expect(s.status).toBe("erro");
    expect(s.errors[0]).toMatch(/Nenhuma fonte/);
    expect(s.warnings.join(" ")).toMatch(/fora do ar/);
    expect((await stepSearch(s.id, deps))?.status).toBe("erro");
  });
  it("fonte cai no meio: resultado parcial, com o que já foi salvo", async () => {
    const store = new MemoryStore();
    const deps = { ...withConnectors(store, { "cnpj-local": fake(companies(80), { throwAt: 10 }) }) };
    const done = await runAll((await createSearch(req({ limit: 60 }), deps)).id, deps);
    expect(done.status).toBe("parcial");
    expect(done.errors.join(" ")).toMatch(/fonte caiu/);
    expect(done.counts.saved).toBeGreaterThan(0);
  });
  it("falha do Google Sheets ao gravar vira erro explícito, sem sucesso falso", async () => {
    class Broken extends MemoryStore {
      override async upsertLeads(): Promise<never> { throw new StoreError("Google Sheets respondeu 503", true, 503); }
    }
    const store = new Broken();
    const deps = withConnectors(store, { "cnpj-local": fake(companies(3)) });
    const done = await runAll((await createSearch(req(), deps)).id, deps);
    expect(done.status).toBe("erro");
    expect(done.counts.saved).toBe(0);
    expect(done.errors[0]).toMatch(/Falha ao gravar/);
  });
  it("cancelamento interrompe a pesquisa", async () => {
    const store = new MemoryStore();
    const deps = withConnectors(store, { "cnpj-local": fake(companies(5)) });
    const s = await createSearch(req(), deps);
    await cancelSearch(s.id, deps);
    const after = await stepSearch(s.id, deps);
    expect(after?.status).toBe("cancelada");
    expect(await store.listLeads()).toHaveLength(0);
  });
  it("pesquisa inexistente devolve null", async () => {
    expect(await stepSearch("nao-existe", withConnectors(new MemoryStore(), {}))).toBeNull();
  });
});
