import { describe, expect, it } from "vitest";
import { findDuplicate, mergeLeads } from "@/lib/leads";
import { lead, makeCnpj } from "./helpers/fixtures";

describe("deduplicação", () => {
  it("usa o CNPJ como identificador principal", () => {
    const a = lead();
    const b = lead({ razaoSocial: "OUTRO NOME", city: "Londrina" });
    expect(findDuplicate(b, [a])).toBe(a);
  });
  it("não funde filiais com CNPJ diferente", () => {
    const matriz = lead();
    const filial = lead({ cnpj: makeCnpj("112223330002") });
    expect(findDuplicate(filial, [matriz])).toBeUndefined();
  });
  it("sem CNPJ, exige nome normalizado + UF + cidade iguais", () => {
    const a = lead({ cnpj: null, razaoSocial: "Alfa Impermeabilização Ltda" });
    const same = lead({ cnpj: null, razaoSocial: "ALFA IMPERMEABILIZACAO", city: "CURITIBA" });
    const otherCity = lead({ cnpj: null, razaoSocial: "ALFA IMPERMEABILIZACAO", city: "Londrina" });
    expect(findDuplicate(same, [a])).toBe(a);
    expect(findDuplicate(otherCity, [a])).toBeUndefined();
  });
  it("não funde nomes apenas semelhantes", () => {
    const a = lead({ cnpj: null, razaoSocial: "ABC Impermeabilizações" });
    const b = lead({ cnpj: null, razaoSocial: "ABC Impermeabilizadora" });
    expect(findDuplicate(b, [a])).toBeUndefined();
  });
  it("não mistura dado fictício com real", () => {
    const real = lead({ cnpj: null, razaoSocial: "ALFA" });
    const demo = lead({ cnpj: null, razaoSocial: "ALFA", isDemo: true, source: "demo" });
    expect(findDuplicate(demo, [real])).toBeUndefined();
  });
});

describe("mesclagem", () => {
  it("preenche vazios sem apagar dados válidos nem campos comerciais", () => {
    const existing = { ...lead({ phone: null, ddd: null }), status: "contatado" as const, notes: "ligar terça" };
    const incoming = lead({ phone: "999998888", ddd: "41", email: "novo@x.com.br", source: "website" });
    const merged = mergeLeads(existing, incoming);
    expect(merged.phone).toBe("(41) 99999-8888");
    expect(merged.email).toBe("contato@testeimper.com.br"); // existente prevalece
    expect(merged.status).toBe("contatado");
    expect(merged.notes).toBe("ligar terça");
    expect(merged.sources).toEqual(["cnpj-local", "website"]);
    expect(merged.provenance["phone"]?.source).toBe("website");
  });
});
