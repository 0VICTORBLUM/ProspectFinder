import { describe, expect, it, vi } from "vitest";
import { LEADS_HEADERS, SheetsStore, type SheetsRequest, type SheetsTransport, leadToRow } from "@/lib/store/sheets";
import { StoreError } from "@/lib/store/types";
import { lead, makeCnpj } from "./helpers/fixtures";

/** Planilha simulada: guarda linhas em memória e responde como a API REST. */
function fakeSheet(opts: { failFirst?: { n: number; status: number } } = {}) {
  const tabs: Record<string, string[][]> = {};
  let failures = opts.failFirst?.n ?? 0;
  const calls: SheetsRequest[] = [];
  const transport: SheetsTransport = async (req) => {
    calls.push(req);
    if (failures > 0 && req.method === "POST" && req.path.includes("append")) {
      failures--;
      return { status: opts.failFirst!.status, data: { error: { message: "simulado" } } };
    }
    const tabOf = (p: string) => decodeURIComponent(p).match(/values\/([^!]+)!/)?.[1] ?? "";
    if (req.method === "GET" && req.path === "") return { status: 200, data: { sheets: Object.keys(tabs).map((title) => ({ properties: { title } })) } };
    if (req.path === ":batchUpdate") {
      for (const r of (req.body as { requests: { addSheet: { properties: { title: string } } }[] }).requests) tabs[r.addSheet.properties.title] = [[]];
      return { status: 200, data: {} };
    }
    if (req.method === "GET") {
      const tab = tabOf(req.path);
      const range = decodeURIComponent(req.path).split("!")[1]!;
      const rows = tabs[tab] ?? [[]];
      if (range.startsWith("A1:")) return { status: 200, data: { values: rows[0]?.length ? [rows[0]] : undefined } };
      const body = rows.slice(1);
      return { status: 200, data: { values: range.startsWith("A2:A") && !range.includes("C") && !range.includes("R") ? body.map((r) => [r[0]]) : body } };
    }
    if (req.path === "/values:batchUpdate") {
      for (const d of (req.body as { data: { range: string; values: string[][] }[] }).data) {
        const [tab, a] = d.range.split("!");
        const m = a!.match(/^A(\d+):/)!;
        const row = Number(m[1]);
        (tabs[tab!] ??= [[]])[row - 1] = d.values[0]!;
      }
      return { status: 200, data: {} };
    }
    if (req.path.includes(":append")) {
      const tab = tabOf(req.path);
      (tabs[tab] ??= [[]]).push(...(req.body as { values: string[][] }).values);
      return { status: 200, data: {} };
    }
    return { status: 404, data: {} };
  };
  return { transport, tabs, calls };
}

const mk = (t: SheetsTransport, extra = {}) => new SheetsStore({ spreadsheetId: "x", transport: t, sleep: async () => {}, ...extra });

describe("SheetsStore", () => {
  it("cria abas e cabeçalhos, insere e lê leads", async () => {
    const f = fakeSheet();
    const s = mk(f.transport);
    const l = lead();
    expect(await s.upsertLeads([l])).toEqual({ inserted: 1, updated: 0 });
    expect(f.tabs["Leads"]?.[0]).toEqual(LEADS_HEADERS);
    expect((await s.listLeads())[0]?.id).toBe(l.id);
    expect((await s.getLead(l.id))?.razaoSocial).toBe(l.razaoSocial);
  });
  it("é idempotente: reenviar o mesmo lead atualiza em vez de duplicar", async () => {
    const f = fakeSheet();
    const s = mk(f.transport);
    const l = lead();
    await s.upsertLeads([l]);
    const r = await s.upsertLeads([{ ...l, status: "qualificado" }]);
    expect(r).toEqual({ inserted: 0, updated: 1 });
    expect(f.tabs["Leads"]).toHaveLength(2);
    expect((await s.listLeads())[0]?.status).toBe("qualificado");
  });
  it("deduplica ids repetidos dentro do mesmo lote e usa lotes grandes", async () => {
    const f = fakeSheet();
    const s = mk(f.transport);
    const many = Array.from({ length: 250 }, (_, i) => lead({ cnpj: makeCnpj(String(100000000001 + i)) }));
    const r = await s.upsertLeads([...many, many[0]!]);
    expect(r.inserted).toBe(250);
    expect(f.calls.filter((c) => c.path.includes(":append"))).toHaveLength(3); // 100 + 100 + 50
  });
  it("tenta novamente em 429/5xx e conclui", async () => {
    const f = fakeSheet({ failFirst: { n: 2, status: 429 } });
    const sleep = vi.fn(async () => {});
    const s = mk(f.transport, { sleep });
    await s.upsertLeads([lead()]);
    expect(sleep).toHaveBeenCalledTimes(2);
    expect(f.tabs["Leads"]).toHaveLength(2);
  });
  it("recupera de falha parcial sem duplicar linhas", async () => {
    const f = fakeSheet({ failFirst: { n: 99, status: 503 } });
    const s = mk(f.transport, { maxAttempts: 2 });
    const l = lead();
    await expect(s.upsertLeads([l])).rejects.toMatchObject({ retryable: true });
    const ok = fakeSheet();
    ok.tabs["Leads"] = f.tabs["Leads"]!;
    await mk(ok.transport).upsertLeads([l]);
    expect(ok.tabs["Leads"]).toHaveLength(2);
  });
  it("não repete erros não retentáveis (403) e expõe a mensagem", async () => {
    const transport: SheetsTransport = async () => ({ status: 403, data: { error: { message: "sem permissão" } } });
    const calls = vi.fn(transport);
    const s = mk(calls);
    await expect(s.listLeads()).rejects.toThrow(/403.*sem permissão/);
    expect(calls).toHaveBeenCalledTimes(1);
  });
  it("trata falha de rede como retentável e desiste após o limite", async () => {
    const transport: SheetsTransport = async () => { throw new Error("ECONNRESET"); };
    const s = mk(transport, { maxAttempts: 3 });
    const err = await s.listLeads().catch((e) => e);
    expect(err).toBeInstanceOf(StoreError);
    expect(err.retryable).toBe(true);
  });
  it("ignora linhas corrompidas ao ler", async () => {
    const f = fakeSheet();
    const s = mk(f.transport);
    await s.upsertLeads([lead()]);
    f.tabs["Leads"]!.push(["x", ...Array(16).fill(""), "{quebrado"]);
    expect(await s.listLeads()).toHaveLength(1);
  });
  it("grava texto cru (RAW) para impedir fórmulas na planilha", async () => {
    const f = fakeSheet();
    await mk(f.transport).upsertLeads([lead({ razaoSocial: "=HYPERLINK(\"http://x\")" })]);
    const writes = f.calls.filter((c) => c.path.includes(":append"));
    expect(writes[0]?.query?.valueInputOption).toBe("RAW");
    expect(leadToRow(lead())).toHaveLength(18);
  });
});
